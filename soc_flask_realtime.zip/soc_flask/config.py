"""
config.py
---------
Single source of truth for every tunable threshold.

Values here are DEFAULTS. The Configuration screen can change the editable
ones at runtime (see EDITABLE below); changes are saved to settings.json
and re-applied on the next start. All other modules read these as
`config.NAME` at call time (never `from config import NAME`), so a change
takes effect immediately without restarting the server.
"""

import json
import os

# ---------------------------------------------------------------------------
# Problem 2: Log Delay / Missing Log Monitoring
# ---------------------------------------------------------------------------
LOG_DELAY_THRESHOLD_SECONDS = 180          # 3 minutes, as specified
LOG_DELAY_CHECK_INTERVAL_SECONDS = 5       # how often the background clock checks

# ---------------------------------------------------------------------------
# Problem 3: Repeated Failed Authentication
# ---------------------------------------------------------------------------
FAILED_LOGIN_THRESHOLD = 10                # failures from one source ...
FAILED_LOGIN_WINDOW_SECONDS = 300          # ... within this sliding window

# ---------------------------------------------------------------------------
# Problem 1: ML-based network anomaly detection
# ---------------------------------------------------------------------------
ML_ENABLED = True
ML_CONTAMINATION = 0.01                    # model hyper-parameter (training only)
ML_ANOMALY_SCORE_THRESHOLD = -0.02         # score below this = suspicious (normal traffic stays above it)
ML_STRONG_SIGNAL_MARGIN = 0.03             # this much further below the threshold = strong signal
ML_PERSISTENCE_COUNT = 5                   # same source flagged this many times = high confidence
ML_BURST_WINDOW_SECONDS = 30               # window for the "connections per source" feature

# ---------------------------------------------------------------------------
# Severity
# ---------------------------------------------------------------------------
SEVERITY_CRITICAL = "Critical"
SEVERITY_MODERATE = "Moderate"
SEVERITY_LOW = "Low"
CRITICAL_ESCALATION_MULTIPLIER = 2.0       # e.g. 2x the failed-login threshold -> Critical

# ---------------------------------------------------------------------------
# Incident grouping
# ---------------------------------------------------------------------------
# Repeated detections for the same (type, source IP) within this many seconds
# are folded into ONE alert (with an occurrence counter) instead of flooding
# the dashboard with one alert per packet. The alert can still be ESCALATED.
ALERT_COOLDOWN_SECONDS = 300

# ---------------------------------------------------------------------------
# Automated response (conservative by design)
# ---------------------------------------------------------------------------
AUTO_RESPONSE_ENABLED = True
AUTO_BLOCK_MIN_SEVERITY = SEVERITY_CRITICAL
AUTO_BLOCK_REQUIRE_HIGH_CONFIDENCE = True
IP_BLOCK_DURATION_HOURS = 24
# Safety net: these addresses are NEVER auto-blocked (e.g. gateway, localhost).
ALLOWLIST_IPS = ["127.0.0.1", "::1", "192.168.1.1"]

# ---------------------------------------------------------------------------
# Storage
# ---------------------------------------------------------------------------
DB_PATH = "soc_system.db"

# ---------------------------------------------------------------------------
# Runtime-editable settings (Configuration screen)
# name -> (type, min, max)
# ---------------------------------------------------------------------------
EDITABLE = {
    "LOG_DELAY_THRESHOLD_SECONDS": (int, 5, 86400),
    "FAILED_LOGIN_THRESHOLD": (int, 2, 1000),
    "FAILED_LOGIN_WINDOW_SECONDS": (int, 10, 86400),
    "IP_BLOCK_DURATION_HOURS": (int, 1, 720),
    "AUTO_RESPONSE_ENABLED": (bool, None, None),
    "ML_ENABLED": (bool, None, None),
}

_SETTINGS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "settings.json")


def current_settings():
    g = globals()
    return {name: g[name] for name in EDITABLE}


def update_settings(values: dict, persist=True):
    """Validate and apply overrides. Returns (applied_dict, errors_list)."""
    g = globals()
    applied, errors = {}, []
    for name, raw in values.items():
        if name not in EDITABLE:
            errors.append(f"{name} is not editable")
            continue
        typ, lo, hi = EDITABLE[name]
        try:
            val = bool(raw) if typ is bool else int(raw)
        except (TypeError, ValueError):
            errors.append(f"{name} must be a {typ.__name__}")
            continue
        if typ is int and not (lo <= val <= hi):
            errors.append(f"{name} must be between {lo} and {hi}")
            continue
        g[name] = val
        applied[name] = val
    if applied and persist:
        try:
            with open(_SETTINGS_FILE, "w") as f:
                json.dump(current_settings(), f, indent=2)
        except OSError:
            pass
    return applied, errors


def _load_overrides():
    if os.path.exists(_SETTINGS_FILE):
        try:
            with open(_SETTINGS_FILE) as f:
                update_settings(json.load(f), persist=False)
        except (OSError, ValueError):
            pass


_load_overrides()
