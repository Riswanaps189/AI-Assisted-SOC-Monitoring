# SentinelSOC - Real-Time AI-Assisted SOC Monitoring (Flask)

A working SOC prototype: logs go in, a hybrid ML + rule engine analyses every event the
moment it arrives, alerts are ranked Critical / Moderate / Low, serious attackers are
blocked automatically (simulated), and everything is shown on the dashboard.
There is **no "Run Scan" button**: detection is continuous.

## Run it

```
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000. The first start trains the ML model (a few seconds).

## 2-minute demo (also your viva demo)

1. Dashboard -> **Start live traffic**. Normal events flow; Log Freshness bars sit near 100%; no alerts.
2. Click **Brute force (25 fails)**. Within seconds: a Critical AUTH alert, the IP is auto-blocked.
3. Click **Brute force (12 fails)**. A Moderate alert appears but is NOT blocked (below the auto-block bar).
4. Click **Mistyped password**. Nothing happens - that is false-positive handling.
5. Click **Port scan** and **Data exfiltration**. The ML model flags them; they escalate to Critical and are blocked.
6. Configuration -> set log delay to 10 seconds, Save. Dashboard -> **Silence firewall-02**. After ~15 s a
   **Log Delay** alert appears (monitoring gap, kept separate from attacks). **Restore** it and the alert closes itself.
7. Response Console -> see every action in the audit trail; **Unblock** an IP; **Test Policy** shows what the rules would do now.
8. Reports -> Executive SOC Report (printable) and Incident Timeline (CSV).

## How it works

```
event (agent / simulator / curl) -> POST /api/ingest -> engine.py
   failed login  -> rule: >= threshold failures from one IP in the window?
   network event -> ML : Isolation Forest finds it unusual?
   -> alert (repeat detections fold into ONE incident and can escalate)
   -> severity -> auto-block only if Critical + high-confidence (allowlist respected)
   -> audit trail -> dashboard (auto-refreshes every 3 s)
background clock (every 5 s): any source silent > threshold -> Log Delay alert; resumes -> auto-closes; expired blocks lifted
```

| File | Role |
|---|---|
| `engine.py` | real-time core: ingest, detect, group incidents, escalate, respond, clock |
| `detection/ml_detector.py` | Isolation Forest: train / save / score (6 features) |
| `detection/rules.py` | the two exact rules: failed logins, silent source |
| `detection/severity.py` | documented severity + high-confidence logic |
| `response/ip_blocker.py` | configurable block / unblock / expiry (simulated firewall) |
| `simulator.py`, `traffic.py` | demo traffic and attack patterns |
| `api.py`, `app.py` | REST API and Flask entry |
| `config.py` | every threshold; editable ones change live from the Configuration screen |
| `agent/` | connect REAL log sources (below) |

## Why ML here and rules there (viva)

* **Rules** for "no log for 3 minutes" and "10 failed logins": exact conditions, a threshold already describes them completely.
* **ML (Isolation Forest)** for network behaviour: "unusual" has no single threshold. It is unsupervised (needs no labelled attacks),
  light, and explainable. Features: uncommon port, log(bytes), protocol, connections per source in 30 s, distinct ports per source
  in 30 s (the port-scan signal), destination internal/external.
* Measured on the built-in traffic: 0 false alarms over 6,000+ normal events; port scan and exfiltration are flagged
  (a single exfiltration packet is Moderate; repeated ones escalate to Critical via the persistence rule).

## Connecting REAL logs

Any program can send events: `POST http://127.0.0.1:5000/api/ingest` with JSON (one event or `{"events":[...]}`):

```
{"event_type":"login_attempt","source_id":"my-pc","src_ip":"10.0.0.5","login_status":"failed","username":"admin"}
{"event_type":"network_connection","source_id":"fw","src_ip":"1.2.3.4","dst_ip":"192.168.1.9","protocol":"TCP","port":4444,"bytes_transferred":900000}
{"event_type":"heartbeat","source_id":"my-pc"}
```
* `python agent/send_event.py failed-login --ip 10.0.0.5 --count 12` - hand-made events, no simulator needed.
* `agent/windows_failed_logins.py` - reads real Windows failed logons (needs an Administrator terminal; see its header).
  Parsing is tested offline; it has not been run on a live Windows PC by its author, so test with a few failed logons first.

## Honest limits (say these in your viva before anyone asks)

* Without an agent, traffic comes from the **simulator**. The detection engine does not care, but the data is synthetic.
* The ML baseline is generated traffic. For a real evaluation (precision / recall / confusion matrix) train on a public dataset
  such as CICIDS2017 or UNSW-NB15 - the natural next step and a strong Results chapter.
* The block is **simulated** (database record + audit trail). A real one would run `netsh advfirewall` / `iptables` / `ufw` in `block_ip()`.
  Do that only on a VM you own; the allowlist stops you blocking yourself.
* No login on the dashboard/API (bind is 127.0.0.1 only). SQLite, single machine.
* Email Security / PCAP / Certificates screens are the mentor's static mockup - outside the approved spec, not connected.
