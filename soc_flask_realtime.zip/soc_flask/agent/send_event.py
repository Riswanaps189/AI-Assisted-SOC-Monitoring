"""
send_event.py - send test events to the running SOC system by hand.

Shows that the system reacts to ANY source that talks to /api/ingest.
Needs only the Python standard library.

Examples (run in a second terminal while `python app.py` is running):
    python agent/send_event.py failed-login --ip 10.0.0.5 --count 12
    python agent/send_event.py heartbeat --source my-laptop
    python agent/send_event.py network --ip 203.0.113.7 --port 4444 --bytes 900000 --count 8
"""

import argparse
import json
import sys
import time
import urllib.error
import urllib.request


def post(url, payload):
    req = urllib.request.Request(url, data=json.dumps(payload).encode(), headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        return json.loads(e.read() or b"{}")
    except urllib.error.URLError as e:
        sys.exit(f"Cannot reach {url}: {e.reason}. Is 'python app.py' running?")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("kind", choices=["failed-login", "heartbeat", "network"])
    ap.add_argument("--url", default="http://127.0.0.1:5000/api/ingest")
    ap.add_argument("--source", default=None, help="source_id (default depends on kind)")
    ap.add_argument("--ip", default="10.0.0.5")
    ap.add_argument("--user", default="admin")
    ap.add_argument("--port", type=int, default=4444)
    ap.add_argument("--bytes", type=int, default=900000)
    ap.add_argument("--count", type=int, default=1)
    ap.add_argument("--delay", type=float, default=0.3, help="seconds between events")
    a = ap.parse_args()

    for i in range(a.count):
        if a.kind == "failed-login":
            ev = {"event_type": "login_attempt", "source_id": a.source or "auth-test", "src_ip": a.ip,
                  "login_status": "failed", "username": a.user}
        elif a.kind == "heartbeat":
            ev = {"event_type": "heartbeat", "source_id": a.source or "test-agent"}
        else:
            ev = {"event_type": "network_connection", "source_id": a.source or "firewall-test", "src_ip": a.ip,
                  "dst_ip": "198.51.100.9", "protocol": "TCP", "port": a.port, "bytes_transferred": a.bytes}
        res = post(a.url, ev)
        print(f"{i + 1}/{a.count}: {res}")
        time.sleep(a.delay)


if __name__ == "__main__":
    main()
