"""
windows_failed_logins.py - feed REAL Windows failed-logon events into the SOC system.

What it does: every few seconds it reads Windows Security event 4625 ("An account
failed to log on") through PowerShell and posts each one to /api/ingest as a
failed login. It also sends a heartbeat so the 3-minute log-delay rule can tell
"the agent died" apart from "nobody failed to log in".

Requirements
  * Windows, and a terminal opened with "Run as administrator" (the Security log
    is admin-only; without it the agent sees nothing).
  * `python app.py` already running.

Usage (Administrator terminal, project folder):
    python agent/windows_failed_logins.py
Make a test failure: run   runas /user:nosuchuser cmd   and type a wrong password,
a few times. Failures from this same PC are logged with a local address, mapped
here to 127.0.0.1, which is on the ALLOWLIST: the alert is raised but the IP is
never auto-blocked (the safety net doing its job).

Status: written against the documented 4625 field layout; the parsing is tested
offline with sample data, but it has not been run on a live Windows machine by its
author. Test it with a few failed logons first.
"""

import argparse
import ctypes
import json
import subprocess
import sys
import time
import urllib.error
import urllib.request

PS_TEMPLATE = r"""
$since = (Get-Date).AddSeconds(-LOOKBACK)
Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4625; StartTime=$since} -ErrorAction SilentlyContinue |
  ForEach-Object { [pscustomobject]@{ Id=$_.RecordId; Time=$_.TimeCreated.ToString('o');
                   User=$_.Properties[5].Value; Ip=$_.Properties[19].Value } } |
  ConvertTo-Json -Compress
"""


def parse_powershell_output(text):
    """PowerShell prints nothing, one object, or a list. Always return a list of dicts."""
    text = (text or "").strip()
    if not text:
        return []
    data = json.loads(text)
    return [data] if isinstance(data, dict) else data


def to_event(rec, source_id):
    ip = (rec.get("Ip") or "").strip()
    if ip in ("", "-", "::1", "::ffff:127.0.0.1"):
        ip = "127.0.0.1"
    return {"event_type": "login_attempt", "source_id": source_id, "src_ip": ip, "login_status": "failed",
            "username": rec.get("User") or "unknown", "timestamp": rec.get("Time")}


def post(url, payload):
    req = urllib.request.Request(url, data=json.dumps(payload).encode(), headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read())


def is_admin():
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="http://127.0.0.1:5000/api/ingest")
    ap.add_argument("--source", default="windows-auth", help="source_id shown on the dashboard")
    ap.add_argument("--interval", type=int, default=5, help="seconds between polls")
    ap.add_argument("--history-seconds", type=int, default=30, help="how far back to look on the first poll")
    a = ap.parse_args()

    if sys.platform != "win32":
        sys.exit("This agent reads the Windows Security log, so it only runs on Windows.")
    if not is_admin():
        print("WARNING: not running as Administrator - the Security log will be unreadable and no events will be seen.")

    seen, lookback, last_beat = set(), a.history_seconds, 0.0
    print(f"Watching Windows failed logons (event 4625) -> {a.url} as source '{a.source}'. Ctrl+C to stop.")
    while True:
        try:
            script = PS_TEMPLATE.replace("LOOKBACK", str(lookback + a.interval))
            out = subprocess.run(["powershell", "-NoProfile", "-Command", script],
                                 capture_output=True, text=True, timeout=60).stdout
            new = [r for r in parse_powershell_output(out) if r.get("Id") not in seen]
            for r in new:
                seen.add(r.get("Id"))
            events = [to_event(r, a.source) for r in sorted(new, key=lambda r: r.get("Time", ""))]
            if time.time() - last_beat > 15:
                events.append({"event_type": "heartbeat", "source_id": a.source})
                last_beat = time.time()
            if events:
                res = post(a.url, {"events": events})
                if new:
                    print(f"sent {len(new)} failed logon(s): {res}")
            lookback = 0
            if len(seen) > 5000:
                seen.clear()
        except urllib.error.URLError as e:
            print("cannot reach the SOC server:", e.reason)
        except Exception as e:
            print("agent error:", e)
        time.sleep(a.interval)


if __name__ == "__main__":
    main()
