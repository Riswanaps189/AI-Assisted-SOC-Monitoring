/*
 * app.js - wires the dashboard to the live Flask API.
 *
 * - The visible screen refreshes itself every 3 seconds, so alerts appear
 *   without any button press.
 * - Every piece of data is HTML-escaped before display (events can come from
 *   outside through /api/ingest, so they are untrusted).
 * - Buttons use data-* attributes + one delegated click handler (no inline
 *   onclick strings built from data).
 * - Email Security / PCAP / Certificates are static mockups: no API calls.
 */

const REFRESH_MS = 3000;
let currentScreen = 'dashboard';
let searchQuery = '';
let simRunning = false;
let silenced = [];
let serverDownShown = false;

// ---------------------------------------------------------------- helpers
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const $ = (id) => document.getElementById(id);

const SEV_PILL = (sev) => {
  const cls = sev === 'Critical' ? 'critical' : sev === 'Moderate' ? 'moderate' : 'low';
  return `<span class="pill ${cls}">${esc(sev)}</span>`;
};
const STATUS_CLASS = (st) =>
  st === 'Open' ? 'status-open' : (st === 'Response Applied' || st === 'Acknowledged') ? 'status-action' : 'status-ok';

function fmtTime(iso) {
  if (!iso || iso === '-') return '-';
  const d = new Date(iso);
  if (isNaN(d)) return esc(iso);
  return d.toLocaleString(undefined, { month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

window.toast = function (msg, ms = 2800) {
  const t = $('toastbox');
  t.textContent = msg;
  t.style.display = 'block';
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(() => (t.style.display = 'none'), ms);
};

async function api(url, method = 'GET', body) {
  const opts = { method };
  if (body !== undefined) {
    opts.headers = { 'Content-Type': 'application/json' };
    opts.body = JSON.stringify(body);
  }
  const res = await fetch(url, opts);
  let data = null;
  try { data = await res.json(); } catch (e) { /* not json */ }
  if (!res.ok && !(data && (data.error || data.errors))) throw new Error(`${url} -> ${res.status}`);
  return data;
}

// ---------------------------------------------------------------- dashboard
async function loadDashboard() {
  let d;
  try {
    d = await api('/api/summary');
    serverDownShown = false;
  } catch (e) {
    $('liveStatus').textContent = 'Server unreachable';
    $('sideStatus').textContent = '● Server unreachable';
    if (!serverDownShown) { toast('Cannot reach the Flask server. Is python app.py still running?', 5000); serverDownShown = true; }
    return;
  }
  simRunning = d.engine.simulator_running;
  silenced = d.engine.silenced || [];

  $('kpiActiveAlerts').textContent = d.active_alerts;
  $('kpiActiveAlertsNote').textContent = d.delayed_sources ? `${d.delayed_sources} silent source(s)` : 'Awaiting action';
  $('kpiActiveAlertsNote').className = 'metric-note ' + (d.active_alerts ? 'warn' : 'good');
  $('kpiCritical').textContent = d.critical_events;
  $('kpiCriticalNote').textContent = d.critical_events ? 'Review auto-responses' : 'None';
  $('kpiResponses').textContent = d.automated_responses;
  $('kpiResponsesNote').textContent = `${d.active_blocks} IP(s) currently restricted`;

  // top bar + sidebar status
  const engineOk = d.engine.monitor_running && d.engine.model_ready;
  $('liveStatus').textContent = engineOk ? (simRunning ? 'Monitoring active · simulator on' : 'Monitoring active') : 'Engine starting…';
  $('sideStatus').textContent = !d.health.length ? '● Waiting for logs'
    : d.delayed_sources ? `● ${d.delayed_sources} source(s) silent` : '● All sources reporting';

  // simulator card
  $('simPill').textContent = simRunning ? 'running' : 'stopped';
  $('simPill').className = 'pill ' + (simRunning ? 'live-on' : 'live-off');
  $('simToggle').textContent = simRunning ? 'Stop live traffic' : 'Start live traffic';
  const isSil = silenced.includes('firewall-02');
  $('silenceBtn').textContent = isSil ? 'Restore firewall-02' : 'Silence firewall-02';

  // activity chart
  const max = Math.max(...d.chart.map((b) => b.events), 1);
  $('mainChart').innerHTML = d.chart.map((b) => {
    const h = b.events ? Math.max(4, Math.round((b.events / max) * 100)) : 2;
    return `<div class="barwrap"><div class="bar ${b.critical ? 'red' : ''}" style="height:${h}%" title="${b.events} events"></div></div>`;
  }).join('');

  // log freshness
  $('healthRows').innerHTML = d.health.length ? d.health.map((h) => {
    const cls = h.pct < 40 ? 'red' : h.pct < 80 ? 'warn' : '';
    return `<div class="healthrow"><span>${esc(h.label)}</span><div class="track"><div class="fill ${cls}" style="width:${h.pct}%"></div></div><b>${h.pct}%</b></div>`;
  }).join('') : '<div class="empty-row">No log sources yet. Start the simulator or send events to /api/ingest.</div>';

  $('dashboardPills').innerHTML =
    `<span class="pill ${d.delayed_sources ? 'moderate' : 'low'}">${d.delayed_sources} silent source(s)</span>` +
    `<span class="pill info">${d.automated_responses} auto response(s)</span>` +
    `<span class="pill low">${d.events_processed} events processed</span>`;

  $('priorityAlerts').innerHTML = d.priority_alerts.length ? d.priority_alerts.map((a) => `
    <div class="alert"><div class="aicon">${a.alert_type === 'LOG_DELAY' ? '≋' : a.alert_type === 'AUTH_FAILURE' ? '♙' : '!'}</div>
    <div><b>${esc(a.description)}</b><p>${esc(a.alert_type.replace('_', ' '))} • ${SEV_PILL(a.severity)} • ${fmtTime(a.updated_at)}</p></div></div>`).join('')
    : '<div class="empty-row">No open alerts. Quiet network, or nothing connected yet.</div>';

  const dist = d.severity_distribution;
  const total = Math.max(dist.critical + dist.moderate + dist.low, 1);
  ['Critical', 'Moderate', 'Low'].forEach((name) => {
    const k = name.toLowerCase();
    $(`dist${name}N`).textContent = dist[k];
    $(`dist${name}Bar`).style.width = `${(dist[k] / total) * 100}%`;
  });
}

// ---------------------------------------------------------------- events
async function loadEvents() {
  const params = new URLSearchParams();
  const sev = $('evsev').value, src = $('evsource').value;
  if (sev !== 'All Severity') params.set('severity', sev);
  if (src !== 'All Sources') params.set('source', src);
  if (searchQuery) params.set('q', searchQuery);
  let rows;
  try { rows = await api(`/api/events?${params}`); } catch (e) { return; }
  $('eventsBody').innerHTML = rows.length ? rows.map((r) => `
    <tr><td>${fmtTime(r.time)}</td><td><b>${esc(r.event)}</b></td><td>${esc(r.src_ip)}</td><td>${esc(r.source)}</td>
    <td>${SEV_PILL(r.severity)}</td><td>${esc(r.detection)}</td><td class="${STATUS_CLASS(r.status)}">${esc(r.status)}</td></tr>`).join('')
    : `<tr><td colspan="7" class="empty-row">${searchQuery ? `No events match “${esc(searchQuery)}”.` : 'No events yet.'}</td></tr>`;
}

// ---------------------------------------------------------------- alerts
async function loadAlerts() {
  let d;
  try { d = await api('/api/alerts'); } catch (e) { return; }
  $('alertCritN').textContent = d.counts.critical;
  $('alertModN').textContent = d.counts.moderate;
  $('alertLowN').textContent = d.counts.low;
  $('alertsBody').innerHTML = d.queue.length ? d.queue.map((a) => {
    const live = a.raw_status === 'OPEN' || a.raw_status === 'RESPONDED' || a.raw_status === 'ACKNOWLEDGED';
    const btns = live ? `<div class="rowbtns">
      ${a.raw_status !== 'ACKNOWLEDGED' ? `<button class="btn small" data-action="ack" data-id="${a.alert_id}">Acknowledge</button>` : ''}
      <button class="btn small" data-action="fp" data-id="${a.alert_id}">False positive</button></div>` : '';
    return `<tr data-alert-id="${a.alert_id}" data-status="${esc(a.raw_status)}"><td>${SEV_PILL(a.priority)}</td><td>${esc(a.finding)}</td>
      <td>${esc(a.source)}</td><td>${esc(a.risk)}</td><td>${esc(a.recommended_action)}</td>
      <td class="${STATUS_CLASS(a.status)}">${esc(a.status)}</td><td>${btns}</td></tr>`;
  }).join('') : '<tr><td colspan="7" class="empty-row">No alerts.</td></tr>';
}

// ---------------------------------------------------------------- logs
async function loadLogs() {
  let d;
  try { d = await api('/api/logs/health'); } catch (e) { return; }
  $('logsMonitoredN').textContent = d.counts.monitored;
  $('logsHealthyN').textContent = d.counts.healthy;
  $('logsDelayedN').textContent = d.counts.delayed;
  $('logsMissingN').textContent = d.counts.missing;
  $('logsBody').innerHTML = d.rows.length ? d.rows.map((r) => `
    <tr><td>${esc(r.source)}</td><td>${fmtTime(r.last_received)}</td><td>${esc(r.alert_after)}</td><td>${esc(r.delay)}</td>
    <td class="${r.status === 'Healthy' ? 'status-ok' : 'status-open'}">${esc(r.status)}</td></tr>`).join('')
    : '<tr><td colspan="5" class="empty-row">No log sources have reported yet.</td></tr>';
}

// ---------------------------------------------------------------- authentication
async function loadAuth() {
  let d;
  try { d = await api('/api/auth/summary'); } catch (e) { return; }
  $('authFailedN').textContent = d.counts.failed_attempts;
  $('authCrossN').textContent = d.counts.threshold_crossings;
  $('authBlockedN').textContent = d.counts.sources_blocked;
  $('authBody').innerHTML = d.rows.length ? d.rows.map((r) => {
    let action;
    if (r.blocked) action = '<span class="status-action">Restricted</span>';
    else if (r.allowlisted) action = '<span class="status-ok">Allowlisted</span>';
    else if (r.crosses_threshold) action = `<button class="btn danger small" data-action="restrict" data-ip="${esc(r.src_ip)}">Restrict IP</button>`;
    else action = `<span class="status-ok">Below threshold (${d.counts.threshold})</span>`;
    return `<tr><td>${esc(r.src_ip)}</td><td>${esc(r.target)}</td><td>${r.failures}</td><td>${esc(r.window)}</td><td>${SEV_PILL(r.severity)}</td><td>${action}</td></tr>`;
  }).join('') : '<tr><td colspan="6" class="empty-row">No failed logins in the current window.</td></tr>';
}

// ---------------------------------------------------------------- response console
async function loadResponse() {
  let d, blocks;
  try { [d, blocks] = await Promise.all([api('/api/response/history'), api('/api/blocks')]); } catch (e) { return; }
  $('respActionsN').textContent = d.counts.actions_today;
  $('respActiveN').textContent = d.counts.active_restrictions;
  $('respPendingN').textContent = d.counts.pending_approval;
  $('blocksBody').innerHTML = blocks.length ? blocks.map((b) => `
    <tr><td>${esc(b.ip)}</td><td>${fmtTime(b.blocked_at)}</td><td>${fmtTime(b.expires_at)}</td><td>${esc(b.triggered_by)}</td>
    <td><button class="btn small" data-action="unblock" data-ip="${esc(b.ip)}">Unblock</button></td></tr>`).join('')
    : '<tr><td colspan="5" class="empty-row">No IPs are currently restricted.</td></tr>';
  $('responseBody').innerHTML = d.rows.length ? d.rows.map((r) => `
    <tr><td>${fmtTime(r.time)}</td><td>${esc(r.trigger)}</td><td>${esc(r.source)}</td><td>${esc(r.actor)}</td><td>${esc(r.action)}</td>
    <td>${esc(r.duration)}</td><td class="${r.status === 'Applied' ? 'status-action' : 'status-ok'}">${esc(r.status)}</td></tr>`).join('')
    : '<tr><td colspan="7" class="empty-row">No response actions recorded yet.</td></tr>';
}

// ---------------------------------------------------------------- configuration
async function loadConfig() {
  const d = await api('/api/config');
  const s = d.settings;
  $('cfgDelay').value = s.LOG_DELAY_THRESHOLD_SECONDS;
  $('cfgFails').value = s.FAILED_LOGIN_THRESHOLD;
  $('cfgWindow').value = s.FAILED_LOGIN_WINDOW_SECONDS;
  $('cfgBlockHrs').value = s.IP_BLOCK_DURATION_HOURS;
  $('cfgMl').checked = s.ML_ENABLED;
  $('cfgAuto').checked = s.AUTO_RESPONSE_ENABLED;
  $('policyPills').innerHTML =
    `<span class="pill ${s.AUTO_RESPONSE_ENABLED ? 'info' : 'moderate'}">Auto response ${s.AUTO_RESPONSE_ENABLED ? 'ON' : 'OFF'}</span>` +
    `<span class="pill info">${s.IP_BLOCK_DURATION_HOURS}-hour IP restriction</span>` +
    `<span class="pill info">Critical + high-confidence only</span>` +
    `<span class="pill info">Allowlist: ${esc(d.allowlist.join(', '))}</span><span class="pill low">Audit logging enabled</span>`;
}

async function saveConfig() {
  const res = await api('/api/config', 'POST', {
    LOG_DELAY_THRESHOLD_SECONDS: $('cfgDelay').value,
    FAILED_LOGIN_THRESHOLD: $('cfgFails').value,
    FAILED_LOGIN_WINDOW_SECONDS: $('cfgWindow').value,
    IP_BLOCK_DURATION_HOURS: $('cfgBlockHrs').value,
    ML_ENABLED: $('cfgMl').checked,
    AUTO_RESPONSE_ENABLED: $('cfgAuto').checked,
  });
  if (res.ok) toast('Configuration saved. It applies immediately to new events.');
  else toast('Not saved: ' + res.errors.join('; '), 6000);
  loadConfig();
}

// ---------------------------------------------------------------- actions (one delegated handler)
document.addEventListener('click', async (ev) => {
  const el = ev.target.closest('[data-action],[data-attack]');
  if (!el) return;
  try {
    if (el.dataset.attack) {
      const r = await api('/api/sim/attack', 'POST', { kind: el.dataset.attack });
      toast(r.message + '. Watch the alerts appear.', 4500);
      return;
    }
    const { action, id, ip } = el.dataset;
    if (action === 'ack') { await api(`/api/alerts/${id}/acknowledge`, 'POST'); toast('Alert acknowledged'); loadAlerts(); }
    else if (action === 'fp') { await api(`/api/alerts/${id}/false-positive`, 'POST'); toast('Marked as false positive and removed from the queue'); loadAlerts(); }
    else if (action === 'restrict') {
      const r = await api('/api/auth/restrict', 'POST', { ip });
      toast(r.ok ? `${ip} restricted` : r.error, 4000); loadAuth();
    } else if (action === 'unblock') { await api('/api/blocks/unblock', 'POST', { ip }); toast(`${ip} unblocked`); loadResponse(); }
  } catch (e) { toast('Action failed: ' + e.message, 4000); }
});

// ---------------------------------------------------------------- screen router + refresh loop
const LOADERS = { dashboard: loadDashboard, events: loadEvents, alerts: loadAlerts, logs: loadLogs, auth: loadAuth, response: loadResponse };

window.onScreenShown = function (id) {
  currentScreen = id;
  if (id === 'settings') loadConfig();
  if (LOADERS[id]) LOADERS[id]();
};

async function refresh() {
  if (document.hidden) return;
  loadDashboard();                                           // keeps top bar / sidebar status live
  if (currentScreen !== 'dashboard' && LOADERS[currentScreen]) LOADERS[currentScreen]();
}

document.addEventListener('DOMContentLoaded', () => {
  $('simToggle').addEventListener('click', async () => {
    await api(simRunning ? '/api/sim/stop' : '/api/sim/start', 'POST');
    toast(simRunning ? 'Live traffic stopped. Silent sources will be flagged after the log-delay threshold.' : 'Live traffic started', 4500);
    loadDashboard();
  });
  $('silenceBtn').addEventListener('click', async () => {
    const isSil = silenced.includes('firewall-02');
    await api('/api/sim/silence', 'POST', { source: 'firewall-02', silenced: !isSil });
    toast(isSil ? 'firewall-02 restored. Its alert will close by itself.' : 'firewall-02 now silent. A Log Delay alert appears after the threshold (default 3 minutes; lower it in Configuration to see it faster).', 7000);
    loadDashboard();
  });
  $('resetBtn').addEventListener('click', async () => {
    if (!confirm('Delete all events, alerts, blocks and history?')) return;
    await api('/api/data/reset', 'POST');
    toast('All data cleared');
    refresh();
  });
  $('ackAllBtn').addEventListener('click', async () => {
    const ids = [...document.querySelectorAll('#alertsBody tr[data-status="OPEN"]')].map((r) => Number(r.dataset.alertId));
    if (!ids.length) return toast('No open alerts to acknowledge');
    const r = await api('/api/alerts/acknowledge-all', 'POST', { ids });
    toast(`${r.acknowledged} alert(s) acknowledged`);
    loadAlerts();
  });
  $('logsCheckBtn').addEventListener('click', async () => { await api('/api/logs/check', 'POST'); toast('Log health re-checked against the clock'); loadLogs(); });
  $('authEvalBtn').addEventListener('click', () => { loadAuth(); toast('Refreshed'); });
  $('respTestBtn').addEventListener('click', async () => { const r = await api('/api/response/test-policy', 'POST'); toast(r.message, 9000); });
  $('saveConfigBtn').addEventListener('click', saveConfig);
  $('evsev').addEventListener('change', loadEvents);
  $('evsource').addEventListener('change', loadEvents);
  $('globalSearch').addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    searchQuery = e.target.value.trim();
    go('events', [...document.querySelectorAll('.nav button')].find((b) => b.textContent.includes('Security Events')));
    toast(searchQuery ? `Showing events matching “${searchQuery}”` : 'Search cleared');
  });

  loadDashboard();
  setInterval(refresh, REFRESH_MS);
});
