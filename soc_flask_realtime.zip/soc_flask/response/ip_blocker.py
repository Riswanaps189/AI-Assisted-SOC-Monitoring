"""
response/ip_blocker.py
------------------------
Configurable automated response: temporarily restrict (block) a source IP.

Auto-block happens ONLY when ALL of these hold (spec: "do not block every
suspicious IP"):
  1. automated response is enabled,
  2. the alert has a source IP that is not on the allowlist,
  3. severity is Critical, and
  4. the alert is HIGH-CONFIDENCE.
Everything else goes to a human.

This is a SIMULATION: it records the block in the database (blocked_ips +
response_log) instead of changing a real firewall. A real deployment would
call a firewall command/API from `block_ip` (iptables, ufw, netsh, a vendor
REST API). Blocks expire automatically after IP_BLOCK_DURATION_HOURS.
"""

from datetime import datetime, timedelta

import config
from db.database import insert_block, insert_response, is_ip_blocked, now_iso


def should_auto_block(alert):
    if not config.AUTO_RESPONSE_ENABLED:
        return False
    ip = alert.get("src_ip")
    if not ip or ip in config.ALLOWLIST_IPS:
        return False
    if alert["severity"] != config.AUTO_BLOCK_MIN_SEVERITY:
        return False
    if config.AUTO_BLOCK_REQUIRE_HIGH_CONFIDENCE and not alert.get("high_confidence"):
        return False
    return True


def block_ip(conn, ip, alert_id, triggered_by, actor, notes):
    """Create the block + audit record. Returns False if already blocked."""
    if is_ip_blocked(conn, ip):
        return False
    now = datetime.now()
    insert_block(conn, {
        "ip": ip, "alert_id": alert_id, "blocked_at": now_iso(now),
        "expires_at": now_iso(now + timedelta(hours=config.IP_BLOCK_DURATION_HOURS)),
        "active": 1, "triggered_by": triggered_by,
    })
    insert_response(conn, {"alert_id": alert_id, "ip": ip, "action": "BLOCK_IP",
                           "actor": actor, "timestamp": now_iso(now), "notes": notes})
    return True


def unblock_ip(conn, ip, actor, notes):
    cur = conn.execute("UPDATE blocked_ips SET active = 0 WHERE ip = ? AND active = 1", (ip,))
    if cur.rowcount:
        insert_response(conn, {"alert_id": None, "ip": ip, "action": "UNBLOCK_IP",
                               "actor": actor, "timestamp": now_iso(), "notes": notes})
    return cur.rowcount > 0


def apply_response(conn, alert, alert_id):
    """Decide and record the automated response for one alert.
    Returns one of: 'BLOCKED', 'ALREADY_BLOCKED', 'NOTIFY_ONLY'."""
    if alert["alert_type"] == "LOG_DELAY":
        insert_response(conn, {"alert_id": alert_id, "ip": None, "action": "NOTIFY_ONLY",
                               "actor": "SYSTEM", "timestamp": now_iso(),
                               "notes": "Log delay: monitoring gap only, there is no IP to act on."})
        return "NOTIFY_ONLY"

    if should_auto_block(alert):
        ip = alert["src_ip"]
        done = block_ip(conn, ip, alert_id, "AUTO", "SYSTEM",
                        f"Auto-blocked {ip} for {config.IP_BLOCK_DURATION_HOURS}h (Critical, high-confidence).")
        return "BLOCKED" if done else "ALREADY_BLOCKED"

    reason = "automated response is disabled" if not config.AUTO_RESPONSE_ENABLED else \
             "below the auto-block bar (needs Critical + high-confidence) - routed to an analyst"
    if alert.get("src_ip") in config.ALLOWLIST_IPS:
        reason = "source is on the allowlist and is never auto-blocked"
    insert_response(conn, {"alert_id": alert_id, "ip": alert.get("src_ip"), "action": "NOTIFY_ONLY",
                           "actor": "SYSTEM", "timestamp": now_iso(), "notes": f"No block: {reason}."})
    return "NOTIFY_ONLY"


def expire_old_blocks(conn):
    """Lift blocks whose time is up and log it."""
    now = now_iso()
    rows = conn.execute("SELECT block_id, ip FROM blocked_ips WHERE active = 1 AND expires_at < ?", (now,)).fetchall()
    for r in rows:
        conn.execute("UPDATE blocked_ips SET active = 0 WHERE block_id = ?", (r["block_id"],))
        insert_response(conn, {"alert_id": None, "ip": r["ip"], "action": "UNBLOCK_IP", "actor": "SYSTEM",
                               "timestamp": now, "notes": f"Block on {r['ip']} expired automatically."})
    return len(rows)
