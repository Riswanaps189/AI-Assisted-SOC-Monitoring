"""
api.py
------
REST API used by the dashboard (templates/index.html + static/js/app.js) and by
any external log source (POST /api/ingest). Every number the dashboard shows is
read from the live database - nothing here is mock data.

Scope: Dashboard, Security Events, Alerts, Log Health, Authentication, Response
Console, Reports and Configuration are fully backed. The Email Security / PCAP /
Certificates screens are the mentor's static mockup (outside the approved spec).
"""

import csv
import io
from datetime import datetime, timedelta
from html import escape

from flask import Blueprint, Response, jsonify, request

import config
from db.database import (
    get_connection, insert_response, update_alert_status, is_ip_blocked, now_iso,
)
from detection import rules
from detection.severity import classify_auth
from engine import engine, fmt_duration
from response.ip_blocker import block_ip, unblock_ip
from simulator import simulator

api = Blueprint("api", __name__, url_prefix="/api")

SEV_ORDER = "CASE severity WHEN 'Critical' THEN 0 WHEN 'Moderate' THEN 1 ELSE 2 END"
STATUS_LABEL = {"OPEN": "Open", "RESPONDED": "Response Applied", "ACKNOWLEDGED": "Acknowledged",
                "FALSE_POSITIVE": "False Positive", "RESOLVED": "Resolved"}
ACTION_LABEL = {"BLOCK_IP": "Temporary IP restriction", "UNBLOCK_IP": "Restriction lifted",
                "NOTIFY_ONLY": "Analyst notified (no block)", "ACKNOWLEDGE": "Acknowledged by analyst",
                "FALSE_POSITIVE": "Marked false positive", "AUTO_RESOLVE": "Auto-resolved"}


def _rows(conn, sql, params=()):
    return [dict(r) for r in conn.execute(sql, params).fetchall()]


def _finding(a):
    text = a["description"] or ""
    if a["alert_type"] == "NETWORK_THREAT" and (a.get("occurrences") or 1) > 1:
        text += f"  [x{a['occurrences']} detections]"
    return text


def _risk(sev):
    return {"Critical": "High", "Moderate": "Medium"}.get(sev, "Low")


def _recommended(a):
    if a["status"] == "FALSE_POSITIVE":
        return "Closed as false positive"
    if a["status"] == "RESOLVED":
        return "Logs resumed - no action"
    if a["alert_type"] == "LOG_DELAY":
        return "Check the source's connectivity / agent"
    if a["status"] == "RESPONDED":
        return "Auto-restricted - review and unblock if wrong"
    if a["alert_type"] == "AUTH_FAILURE":
        return "Investigate; restrict IP if it is an attack"
    return "Escalate to analyst for review"


def _active_filter():
    return "status NOT IN ('FALSE_POSITIVE')"


# ---------------------------------------------------------------------------
# Live ingestion  (the "real" entry point)
# ---------------------------------------------------------------------------
@api.post("/ingest")
def ingest():
    payload = request.get_json(force=True, silent=True)
    if payload is None:
        return jsonify({"ok": False, "error": "body must be JSON"}), 400
    events = payload["events"] if isinstance(payload, dict) and "events" in payload else [payload]
    if not isinstance(events, list) or len(events) > 1000:
        return jsonify({"ok": False, "error": "send one event object or {\"events\": [...]} (max 1000)"}), 400
    accepted, rejected = 0, []
    for i, ev in enumerate(events):
        try:
            engine.ingest(ev)
            accepted += 1
        except ValueError as exc:
            rejected.append({"index": i, "error": str(exc)})
    return jsonify({"ok": not rejected, "accepted": accepted, "rejected": rejected}), (200 if accepted else 400)


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------
@api.get("/summary")
def summary():
    now = datetime.now()
    with get_connection() as conn:
        alerts = _rows(conn, f"SELECT * FROM alerts WHERE {_active_filter()} ORDER BY updated_at DESC")
        events_count = conn.execute("SELECT COUNT(*) n FROM events").fetchone()["n"]
        auto_blocks = conn.execute("SELECT COUNT(*) n FROM response_log WHERE action='BLOCK_IP' AND actor='SYSTEM'").fetchone()["n"]
        active_blocks = conn.execute("SELECT COUNT(*) n FROM blocked_ips WHERE active=1").fetchone()["n"]
        sources = _rows(conn, "SELECT source_id FROM sources ORDER BY source_id")
        health = []
        for s in sources:
            gap, _ = rules.source_gap_seconds(conn, s["source_id"], now)
            if gap is None:
                continue
            pct = max(5, int(100 - 50 * gap / max(config.LOG_DELAY_THRESHOLD_SECONDS, 1)))
            health.append({"label": s["source_id"], "pct": min(100, pct), "gap": int(gap)})

        # activity chart: events per minute for the last 15 minutes; red = a Critical alert started then
        minute0 = now.replace(second=0, microsecond=0) - timedelta(minutes=14)
        since = now_iso(minute0)
        ev_counts = {r["m"]: r["n"] for r in conn.execute(
            "SELECT substr(timestamp,1,16) m, COUNT(*) n FROM events WHERE timestamp >= ? GROUP BY m", (since,))}
        crit = {r["m"] for r in conn.execute(
            "SELECT substr(created_at,1,16) m FROM alerts WHERE severity='Critical' AND created_at >= ? AND status != 'FALSE_POSITIVE'", (since,))}
    buckets = []
    for i in range(15):
        key = (minute0 + timedelta(minutes=i)).isoformat(timespec="minutes")
        buckets.append({"events": ev_counts.get(key, 0), "critical": key in crit})

    security = [a for a in alerts if a["alert_type"] != "LOG_DELAY"]
    open_alerts = [a for a in alerts if a["status"] == "OPEN"]
    dist = {k: sum(1 for a in security if a["severity"] == v) for k, v in
            (("critical", "Critical"), ("moderate", "Moderate"), ("low", "Low"))}
    priority = [a for a in alerts if a["status"] in ("OPEN", "RESPONDED")][:5]
    delayed = sum(1 for a in alerts if a["alert_type"] == "LOG_DELAY" and a["status"] in ("OPEN", "ACKNOWLEDGED"))

    return jsonify({
        "active_alerts": len(open_alerts), "critical_events": dist["critical"],
        "automated_responses": auto_blocks, "active_blocks": active_blocks,
        "events_processed": events_count, "severity_distribution": dist,
        "chart": buckets, "health": health, "delayed_sources": delayed,
        "priority_alerts": [{"alert_id": a["alert_id"], "alert_type": a["alert_type"], "severity": a["severity"],
                             "description": _finding(a), "updated_at": a["updated_at"]} for a in priority],
        "engine": {"monitor_running": engine.monitor_running, "model_ready": engine.model is not None,
                   "ml_enabled": config.ML_ENABLED, "simulator_running": simulator.running,
                   "silenced": sorted(simulator.silenced)},
    })


# ---------------------------------------------------------------------------
# Security events / alerts
# ---------------------------------------------------------------------------
@api.get("/events")
def events_list():
    sql, params = f"SELECT * FROM alerts WHERE {_active_filter()}", []
    if request.args.get("severity") not in (None, "", "All Severity"):
        sql += " AND severity = ?"; params.append(request.args["severity"])
    if request.args.get("source") not in (None, "", "All Sources"):
        sql += " AND source_id LIKE ?"; params.append(f"%{request.args['source']}%")
    q = (request.args.get("q") or "").strip()
    if q:
        sql += " AND (src_ip LIKE ? OR description LIKE ? OR source_id LIKE ? OR alert_type LIKE ?)"
        params += [f"%{q}%"] * 4
    sql += " ORDER BY updated_at DESC LIMIT 200"
    with get_connection() as conn:
        rows = _rows(conn, sql, params)
    return jsonify([{
        "time": r["updated_at"], "event": _finding(r), "src_ip": r["src_ip"] or "-",
        "source": r["source_id"] or "-", "severity": r["severity"],
        "detection": "AI Model" if r["detection_method"] == "ML" else "Rule / Threshold",
        "status": STATUS_LABEL.get(r["status"], r["status"]),
    } for r in rows])


@api.get("/alerts")
def alerts_list():
    with get_connection() as conn:
        rows = _rows(conn, f"SELECT * FROM alerts WHERE {_active_filter()} ORDER BY "
                           f"CASE WHEN status='RESOLVED' THEN 1 ELSE 0 END, {SEV_ORDER}, updated_at DESC LIMIT 300")
    sec = [r for r in rows if r["alert_type"] != "LOG_DELAY"]
    counts = {k: sum(1 for r in sec if r["severity"] == v) for k, v in
              (("critical", "Critical"), ("moderate", "Moderate"), ("low", "Low"))}
    return jsonify({"counts": counts, "queue": [{
        "alert_id": r["alert_id"], "priority": r["severity"], "finding": _finding(r),
        "source": r["src_ip"] or r["source_id"] or "-", "risk": _risk(r["severity"]),
        "recommended_action": _recommended(r), "status": STATUS_LABEL.get(r["status"], r["status"]),
        "raw_status": r["status"], "type": r["alert_type"],
    } for r in rows]})


def _analyst_action(alert_id, status, action, note):
    with get_connection() as conn:
        row = conn.execute("SELECT src_ip FROM alerts WHERE alert_id = ?", (alert_id,)).fetchone()
        if not row:
            return False
        update_alert_status(conn, alert_id, status)
        insert_response(conn, {"alert_id": alert_id, "ip": row["src_ip"], "action": action,
                               "actor": "ANALYST", "timestamp": now_iso(), "notes": note})
    return True


@api.post("/alerts/<int:alert_id>/acknowledge")
def acknowledge(alert_id):
    ok = _analyst_action(alert_id, "ACKNOWLEDGED", "ACKNOWLEDGE", "Acknowledged from the dashboard.")
    return jsonify({"ok": ok}), (200 if ok else 404)


@api.post("/alerts/<int:alert_id>/false-positive")
def false_positive(alert_id):
    ok = _analyst_action(alert_id, "FALSE_POSITIVE", "FALSE_POSITIVE",
                         "Analyst marked this alert as a false positive.")
    return jsonify({"ok": ok}), (200 if ok else 404)


@api.post("/alerts/acknowledge-all")
def acknowledge_all():
    ids = (request.get_json(silent=True) or {}).get("ids", [])
    done = sum(1 for i in ids if _analyst_action(int(i), "ACKNOWLEDGED", "ACKNOWLEDGE", "Bulk acknowledge from the dashboard."))
    return jsonify({"ok": True, "acknowledged": done})


# ---------------------------------------------------------------------------
# Log health  (Problem 2)
# ---------------------------------------------------------------------------
@api.post("/logs/check")
def logs_check():
    engine.check_log_delays()
    return jsonify({"ok": True})


@api.get("/logs/health")
def logs_health():
    now = datetime.now()
    thr = config.LOG_DELAY_THRESHOLD_SECONDS
    rows, counts = [], {"healthy": 0, "delayed": 0, "missing": 0}
    with get_connection() as conn:
        for s in _rows(conn, "SELECT * FROM sources ORDER BY source_id"):
            gap, last = rules.source_gap_seconds(conn, s["source_id"], now)
            if gap is None:
                continue
            if gap <= thr:
                status, key = "Healthy", "healthy"
            elif gap <= thr * 3:
                status, key = f"Delayed > {fmt_duration(thr)}", "delayed"
            else:
                status, key = "Missing", "missing"
            counts[key] += 1
            rows.append({"source": s["source_id"], "type": s["source_type"], "last_received": last.isoformat(),
                         "alert_after": fmt_duration(thr), "delay": fmt_duration(gap), "status": status})
    return jsonify({"counts": {"monitored": len(rows), **counts}, "rows": rows})


# ---------------------------------------------------------------------------
# Authentication  (Problem 3)
# ---------------------------------------------------------------------------
@api.get("/auth/summary")
def auth_summary():
    now = datetime.now()
    since = now_iso(now - timedelta(seconds=config.FAILED_LOGIN_WINDOW_SECONDS))
    with get_connection() as conn:
        total_failed = conn.execute("SELECT COUNT(*) n FROM events WHERE login_status='failed'").fetchone()["n"]
        window = _rows(conn, "SELECT src_ip, COUNT(*) n, GROUP_CONCAT(DISTINCT username) users FROM events "
                             "WHERE event_type='login_attempt' AND login_status='failed' AND timestamp >= ? GROUP BY src_ip", (since,))
        alerts = _rows(conn, "SELECT src_ip, occurrences, detail_json FROM alerts WHERE alert_type='AUTH_FAILURE' "
                             "AND status != 'FALSE_POSITIVE' AND updated_at >= ?", (now_iso(now - timedelta(hours=1)),))
        crossings = conn.execute("SELECT COUNT(*) n FROM alerts WHERE alert_type='AUTH_FAILURE' AND status != 'FALSE_POSITIVE'").fetchone()["n"]
        blocked_ips = {r["ip"] for r in conn.execute("SELECT ip FROM blocked_ips WHERE active=1")}
        auth_blocked = conn.execute(
            "SELECT COUNT(DISTINCT b.ip) n FROM blocked_ips b JOIN alerts a ON a.alert_id=b.alert_id "
            "WHERE a.alert_type='AUTH_FAILURE' AND b.active=1").fetchone()["n"]
    merged = {}
    for r in window:
        merged[r["src_ip"]] = {"n": r["n"], "users": r["users"] or "unknown"}
    for a in alerts:                      # keep an attacker visible after its window slides past
        cur = merged.setdefault(a["src_ip"], {"n": 0, "users": "-"})
        cur["n"] = max(cur["n"], a["occurrences"] or 0)
    rows = []
    for ip, v in sorted(merged.items(), key=lambda kv: -kv[1]["n"])[:25]:
        sev, _ = classify_auth(v["n"])
        rows.append({"src_ip": ip, "target": v["users"], "failures": v["n"],
                     "window": fmt_duration(config.FAILED_LOGIN_WINDOW_SECONDS), "severity": sev,
                     "crosses_threshold": v["n"] >= config.FAILED_LOGIN_THRESHOLD,
                     "blocked": ip in blocked_ips, "allowlisted": ip in config.ALLOWLIST_IPS})
    return jsonify({"counts": {"failed_attempts": total_failed, "threshold_crossings": crossings,
                               "sources_blocked": auth_blocked, "threshold": config.FAILED_LOGIN_THRESHOLD},
                    "rows": rows})


@api.post("/auth/restrict")
def auth_restrict():
    ip = ((request.get_json(force=True, silent=True) or {}).get("ip") or "").strip()
    if not ip:
        return jsonify({"ok": False, "error": "ip is required"}), 400
    if ip in config.ALLOWLIST_IPS:
        return jsonify({"ok": False, "error": f"{ip} is on the allowlist and cannot be restricted"}), 400
    with get_connection() as conn:
        done = block_ip(conn, ip, None, "MANUAL", "ANALYST",
                        f"Manually restricted {ip} for {config.IP_BLOCK_DURATION_HOURS}h.")
    return jsonify({"ok": True, "already_blocked": not done})


# ---------------------------------------------------------------------------
# Response console
# ---------------------------------------------------------------------------
@api.get("/blocks")
def blocks_list():
    with get_connection() as conn:
        rows = _rows(conn, "SELECT * FROM blocked_ips WHERE active = 1 ORDER BY blocked_at DESC")
    return jsonify(rows)


@api.post("/blocks/unblock")
def blocks_unblock():
    ip = ((request.get_json(force=True, silent=True) or {}).get("ip") or "").strip()
    with get_connection() as conn:
        ok = unblock_ip(conn, ip, "ANALYST", f"Restriction on {ip} lifted manually.")
    return jsonify({"ok": ok}), (200 if ok else 404)


@api.get("/response/history")
def response_history():
    today = now_iso(datetime.now().replace(hour=0, minute=0, second=0, microsecond=0))
    with get_connection() as conn:
        rows = _rows(conn, "SELECT r.*, a.alert_type FROM response_log r LEFT JOIN alerts a ON r.alert_id=a.alert_id "
                           "ORDER BY r.response_id DESC LIMIT 200")
        today_n = conn.execute("SELECT COUNT(*) n FROM response_log WHERE timestamp >= ?", (today,)).fetchone()["n"]
        active = conn.execute("SELECT COUNT(*) n FROM blocked_ips WHERE active=1").fetchone()["n"]
        pending = conn.execute("SELECT COUNT(*) n FROM alerts WHERE status='OPEN' AND alert_type!='LOG_DELAY' "
                               "AND severity IN ('Critical','Moderate')").fetchone()["n"]
    status_map = {"BLOCK_IP": "Applied", "UNBLOCK_IP": "Lifted", "AUTO_RESOLVE": "Resolved"}
    return jsonify({"counts": {"actions_today": today_n, "active_restrictions": active, "pending_approval": pending},
                    "rows": [{"time": r["timestamp"], "trigger": r["notes"] or "", "source": r["ip"] or "-",
                              "actor": r["actor"].title(), "action": ACTION_LABEL.get(r["action"], r["action"]),
                              "duration": f"{config.IP_BLOCK_DURATION_HOURS} hours" if r["action"] == "BLOCK_IP" else "-",
                              "status": status_map.get(r["action"], "Logged")} for r in rows]})


@api.post("/response/test-policy")
def test_policy():
    """Dry run: what would the current policy do to alerts that are open right now?"""
    with get_connection() as conn:
        rows = _rows(conn, "SELECT * FROM alerts WHERE status IN ('OPEN','ACKNOWLEDGED') AND alert_type!='LOG_DELAY'")
        blocked = {r["ip"] for r in conn.execute("SELECT ip FROM blocked_ips WHERE active=1")}
    eligible = [a for a in rows if a["severity"] == config.AUTO_BLOCK_MIN_SEVERITY and a["high_confidence"]
                and a["src_ip"] and a["src_ip"] not in config.ALLOWLIST_IPS and a["src_ip"] not in blocked]
    held = len(rows) - len(eligible)
    if not config.AUTO_RESPONSE_ENABLED:
        msg = f"Automated response is OFF: all {len(rows)} open alert(s) would go to an analyst, nothing would be blocked."
    else:
        msg = (f"Policy test: {len(eligible)} open alert(s) meet Critical + high-confidence and would be blocked for "
               f"{config.IP_BLOCK_DURATION_HOURS}h; {held} would be held for an analyst. Allowlist: {', '.join(config.ALLOWLIST_IPS)}.")
    return jsonify({"ok": True, "message": msg, "would_block": [a["src_ip"] for a in eligible]})


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
@api.get("/config")
def config_get():
    return jsonify({"settings": config.current_settings(), "allowlist": config.ALLOWLIST_IPS})


@api.post("/config")
def config_set():
    applied, errors = config.update_settings(request.get_json(force=True, silent=True) or {})
    return jsonify({"ok": not errors, "applied": applied, "errors": errors}), (200 if not errors else 400)


# ---------------------------------------------------------------------------
# Simulator control + data reset
# ---------------------------------------------------------------------------
@api.get("/sim/status")
def sim_status():
    return jsonify(simulator.status())


@api.post("/sim/start")
def sim_start():
    return jsonify({"ok": True, "started": simulator.start()})


@api.post("/sim/stop")
def sim_stop():
    simulator.stop()
    return jsonify({"ok": True})


@api.post("/sim/attack")
def sim_attack():
    kind = (request.get_json(force=True, silent=True) or {}).get("kind")
    try:
        return jsonify({"ok": True, "message": simulator.attack(kind)})
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400


@api.post("/sim/silence")
def sim_silence():
    body = request.get_json(force=True, silent=True) or {}
    try:
        simulator.set_silenced(body.get("source"), bool(body.get("silenced")))
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400
    return jsonify({"ok": True, **simulator.status()})


@api.post("/data/reset")
def data_reset():
    engine.reset()
    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# Reports (generated on demand from live data)
# ---------------------------------------------------------------------------
def _csv_response(name, header, rows):
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(header)
    w.writerows(rows)
    return Response(buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename={name}"})


@api.get("/report/alerts.csv")
def report_alerts_csv():
    with get_connection() as conn:
        rows = _rows(conn, "SELECT * FROM alerts ORDER BY alert_id")
    cols = ["alert_id", "alert_type", "severity", "detection_method", "src_ip", "source_id", "occurrences",
            "high_confidence", "status", "created_at", "updated_at", "description"]
    return _csv_response("soc_alerts.csv", cols, [[r[c] for c in cols] for r in rows])


@api.get("/report/incidents.csv")
def report_incidents_csv():
    with get_connection() as conn:
        alerts = _rows(conn, "SELECT * FROM alerts")
        resp = _rows(conn, "SELECT * FROM response_log")
    timeline = [[a["created_at"], "ALERT", a["alert_id"], a["alert_type"], a["severity"], a["src_ip"] or "",
                 "SYSTEM", a["description"]] for a in alerts]
    timeline += [[r["timestamp"], "RESPONSE", r["alert_id"] or "", r["action"], "", r["ip"] or "", r["actor"],
                  r["notes"] or ""] for r in resp]
    timeline.sort(key=lambda x: x[0])
    return _csv_response("soc_incident_timeline.csv",
                         ["time", "kind", "alert_id", "type_or_action", "severity", "ip", "actor", "details"], timeline)


@api.get("/report/soc.html")
def report_soc_html():
    now = datetime.now()
    with get_connection() as conn:
        alerts = _rows(conn, f"SELECT * FROM alerts WHERE {_active_filter()} ORDER BY {SEV_ORDER}, updated_at DESC LIMIT 25")
        by_sev = _rows(conn, "SELECT severity, COUNT(*) n FROM alerts WHERE status != 'FALSE_POSITIVE' AND alert_type!='LOG_DELAY' GROUP BY severity")
        by_type = _rows(conn, "SELECT alert_type, COUNT(*) n FROM alerts WHERE status != 'FALSE_POSITIVE' GROUP BY alert_type")
        blocks = _rows(conn, "SELECT * FROM blocked_ips WHERE active=1 ORDER BY blocked_at DESC")
        n_events = conn.execute("SELECT COUNT(*) n FROM events").fetchone()["n"]
        n_resp = conn.execute("SELECT COUNT(*) n FROM response_log").fetchone()["n"]
    sev = {r["severity"]: r["n"] for r in by_sev}

    def table(head, body):
        return "<table><tr>" + "".join(f"<th>{escape(h)}</th>" for h in head) + "</tr>" + "".join(
            "<tr>" + "".join(f"<td>{escape(str(c))}</td>" for c in row) + "</tr>" for row in body) + "</table>"

    html = f"""<!DOCTYPE html><html><head><meta charset="utf-8"><title>SOC Report</title><style>
body{{font-family:Segoe UI,Arial,sans-serif;max-width:900px;margin:30px auto;padding:0 20px;color:#172033}}
h1{{margin-bottom:2px}}h2{{margin-top:28px;border-bottom:1px solid #ddd;padding-bottom:4px;font-size:17px}}
.meta{{color:#667085;font-size:13px}}table{{border-collapse:collapse;width:100%;font-size:12.5px;margin-top:8px}}
th,td{{border:1px solid #e5e9f0;padding:6px 8px;text-align:left;vertical-align:top}}th{{background:#f4f6fa}}
.kpis{{display:flex;gap:12px;margin-top:14px}}.kpi{{flex:1;border:1px solid #e5e9f0;border-radius:8px;padding:10px}}
.kpi b{{font-size:22px;display:block}}button{{margin-top:14px;padding:8px 14px}}@media print{{button{{display:none}}}}
</style></head><body><h1>Executive SOC Report</h1>
<div class="meta">AI-Assisted SOC Monitoring and Automated Threat Response System &middot; generated {escape(now.strftime('%d %b %Y, %H:%M:%S'))}</div>
<button onclick="window.print()">Print / Save as PDF</button>
<div class="kpis"><div class="kpi"><b>{n_events}</b>events processed</div><div class="kpi"><b>{sev.get('Critical',0)}</b>critical</div>
<div class="kpi"><b>{sev.get('Moderate',0)}</b>moderate</div><div class="kpi"><b>{sev.get('Low',0)}</b>low</div>
<div class="kpi"><b>{len(blocks)}</b>active IP restrictions</div><div class="kpi"><b>{n_resp}</b>response actions</div></div>
<h2>Alerts by type</h2>{table(['Type','Count'], [[r['alert_type'], r['n']] for r in by_type]) if by_type else '<p>No alerts.</p>'}
<h2>Top alerts (most severe first)</h2>{table(['ID','Type','Severity','Source','Status','Description'],
 [[a['alert_id'],a['alert_type'],a['severity'],a['src_ip'] or a['source_id'] or '-',STATUS_LABEL.get(a['status'],a['status']),_finding(a)] for a in alerts]) if alerts else '<p>No alerts.</p>'}
<h2>Active IP restrictions</h2>{table(['IP','Blocked at','Expires','Triggered by'],
 [[b['ip'],b['blocked_at'],b['expires_at'],b['triggered_by']] for b in blocks]) if blocks else '<p>None.</p>'}
<h2>Policy in force</h2>{table(['Setting','Value'],[
 ['Log delay threshold', fmt_duration(config.LOG_DELAY_THRESHOLD_SECONDS)],
 ['Failed-login threshold', f'{config.FAILED_LOGIN_THRESHOLD} in {fmt_duration(config.FAILED_LOGIN_WINDOW_SECONDS)}'],
 ['Automated response', 'ON' if config.AUTO_RESPONSE_ENABLED else 'OFF'],
 ['Block duration', f'{config.IP_BLOCK_DURATION_HOURS} h (only Critical + high-confidence)'],
 ['ML detection', 'ON' if config.ML_ENABLED else 'OFF']])}
</body></html>"""
    return Response(html, mimetype="text/html")
