"""
simulator.py
------------
A live traffic generator for demos and testing. It is NOT part of detection:
it only produces events and hands them to engine.ingest(), exactly the path a
real agent or firewall would use. Stop it, and the system keeps working on
whatever real events arrive.

Background traffic (Start): normal firewall + login events and heartbeats from
three sources (firewall-01, firewall-02, auth-server-01), in real time.

Attack buttons (work with or without the background traffic):
  portscan, exfil, bruteforce_moderate, bruteforce_severe, mistyped

"Silence" stops one source from sending, so after the log-delay threshold the
Log Delay alert fires; "Restore" lets it resume and the alert closes itself.

SOC_SIM_SPEED (env var) speeds everything up for automated tests; leave unset.
"""

import os
import random
import threading
import time
from datetime import datetime

import traffic as T
from engine import engine

SPEED = float(os.environ.get("SOC_SIM_SPEED", "1"))
SOURCES = ["firewall-01", "firewall-02", "auth-server-01"]

ATTACKS = {
    "portscan": "Port scan: one outside IP probes ~40 different ports",
    "exfil": "Data exfiltration: an internal host sends huge transfers to an uncommon port",
    "bruteforce_moderate": "Brute force (12 failed logins): crosses the threshold, below auto-block",
    "bruteforce_severe": "Brute force (25 failed logins): clear attack, auto-block expected",
    "mistyped": "Mistyped password: 5 failures then success (should NOT alert)",
}


def _sleep(seconds):
    time.sleep(seconds / SPEED)


def _safe_ingest(event):
    try:
        engine.ingest(event)
    except Exception as exc:          # a simulator hiccup must never kill the thread
        print("simulator ingest error:", exc)


class Simulator:
    def __init__(self):
        self.running = False
        self.silenced = set()
        self._thread = None
        self._lock = threading.Lock()
        self.rng = random.Random()
        self.active_attacks = 0

    # --------------------------------------------------------------- background traffic
    def start(self):
        with self._lock:
            if self.running:
                return False
            self.running = True
            self._thread = threading.Thread(target=self._loop, name="soc-sim", daemon=True)
            self._thread.start()
            return True

    def stop(self):
        self.running = False

    def _loop(self):
        tick = 0
        while self.running:
            now = datetime.now()
            if "firewall-01" not in self.silenced:
                _safe_ingest(T.normal_network_event(now, "firewall-01", self.rng))
            if tick % 2 == 0 and "firewall-02" not in self.silenced:
                _safe_ingest(T.normal_network_event(now, "firewall-02", self.rng))
            if tick % 4 == 0 and "auth-server-01" not in self.silenced:
                _safe_ingest(T.normal_login_event(now, "auth-server-01", self.rng))
            if tick % 20 == 0:                       # heartbeats keep quiet sources provably alive
                for s in SOURCES:
                    if s not in self.silenced:
                        _safe_ingest(T.heartbeat_event(now, s))
            tick += 1
            _sleep(0.7)

    # --------------------------------------------------------------- silence / restore
    def set_silenced(self, source, silenced):
        if source not in SOURCES:
            raise ValueError(f"unknown source {source}")
        if silenced:
            self.silenced.add(source)
        else:
            self.silenced.discard(source)
            _safe_ingest(T.heartbeat_event(datetime.now(), source))   # resume immediately

    # --------------------------------------------------------------- attacks
    def attack(self, kind):
        if kind not in ATTACKS:
            raise ValueError(f"unknown attack {kind}")
        threading.Thread(target=self._run_attack, args=(kind,), name=f"soc-attack-{kind}", daemon=True).start()
        return ATTACKS[kind]

    def _attacker(self):
        return f"203.0.113.{self.rng.randint(10, 250)}"

    def _run_attack(self, kind):
        self.active_attacks += 1
        try:
            rng = self.rng
            if kind == "portscan":
                ip = self._attacker()
                for _ in range(40):
                    _safe_ingest(T.portscan_event(datetime.now(), ip, rng=rng)); _sleep(0.5)
            elif kind == "exfil":
                host, dest = f"192.168.1.{rng.randint(40, 60)}", f"198.51.100.{rng.randint(10, 250)}"
                for _ in range(8):
                    _safe_ingest(T.exfil_event(datetime.now(), host, dest, rng=rng)); _sleep(1.0)
            elif kind in ("bruteforce_moderate", "bruteforce_severe"):
                ip = self._attacker()
                n, user = (12, "admin") if kind == "bruteforce_moderate" else (25, "root")
                for _ in range(n):
                    _safe_ingest(T.failed_login_event(datetime.now(), ip, user)); _sleep(0.4)
            elif kind == "mistyped":
                ip = f"192.168.1.{rng.randint(100, 140)}"
                for _ in range(5):
                    _safe_ingest(T.failed_login_event(datetime.now(), ip, "carol")); _sleep(1.0)
                _safe_ingest(T.success_login_event(datetime.now(), ip, "carol"))
        finally:
            self.active_attacks -= 1

    def status(self):
        return {"running": self.running, "silenced": sorted(self.silenced),
                "active_attacks": self.active_attacks, "attacks": ATTACKS}


simulator = Simulator()
