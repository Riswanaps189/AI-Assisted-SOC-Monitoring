"""
traffic.py
----------
Pure event generators (no database, no threads). Used for two things:

1. Training the ML model: `baseline_events()` produces a few thousand
   "normal" firewall events so the Isolation Forest learns what ordinary
   traffic looks like. (With a real deployment you would train on a public
   dataset such as CICIDS2017 or UNSW-NB15 instead - see README.)
2. The live simulator (simulator.py): normal background traffic and the
   attack patterns used for demos.

Every function returns a plain dict with the same fields the /api/ingest
endpoint accepts, so simulated events travel the exact same path as events
sent by a real agent.
"""

import random
from datetime import datetime, timedelta

COMMON_PORTS = [80, 443, 22, 3389, 53, 8080, 25, 143, 445, 8443]
SUSPICIOUS_PORTS = [4444, 6667, 31337, 1337, 5555]
NORMAL_USERS = ["alice", "bob", "carol", "dave", "erin", "frank"]

# A handful of legitimately busy internal hosts (proxies, build servers...)
HEAVY_HITTERS = [f"192.168.1.{n}" for n in (20, 21, 22, 30, 31)]


def internal_ip(rng=random):
    return f"192.168.1.{rng.randint(2, 254)}"


def external_ip(rng=random):
    return f"{rng.choice([34, 52, 104, 142, 151, 172])}.{rng.randint(0, 255)}.{rng.randint(0, 255)}.{rng.randint(1, 254)}"


def _event(ts, **kw):
    base = {
        "source_id": None, "event_type": None, "timestamp": ts.isoformat(timespec="microseconds"),
        "src_ip": None, "dst_ip": None, "protocol": None, "port": None,
        "bytes_transferred": None, "login_status": None, "username": None,
    }
    base.update(kw)
    return base


# ---------------------------------------------------------------------------
# Normal traffic
# ---------------------------------------------------------------------------
def normal_network_event(ts, source_id="firewall-01", rng=random):
    r = rng.random()
    if r < 0.30:        # busy internal host
        src, dst, port = rng.choice(HEAVY_HITTERS), internal_ip(rng), rng.choice([80, 443, 8080, 445])
    elif r < 0.75:      # internal -> internal
        src, dst, port = internal_ip(rng), internal_ip(rng), rng.choice(COMMON_PORTS)
    elif r < 0.95:      # internal -> internet (web, DNS)
        src, dst, port = internal_ip(rng), external_ip(rng), rng.choice([80, 443, 53, 443, 443])
    else:               # internet -> public servers
        src, dst, port = external_ip(rng), internal_ip(rng), rng.choice([80, 443])
    nbytes = rng.randint(200, 5000) if rng.random() < 0.95 else rng.randint(5000, 80000)
    return _event(ts, source_id=source_id, event_type="network_connection", src_ip=src,
                  dst_ip=dst, protocol=rng.choice(["TCP", "TCP", "TCP", "UDP"]),
                  port=port, bytes_transferred=nbytes)


def normal_login_event(ts, source_id="auth-server-01", rng=random, fail_rate=0.07):
    ok = rng.random() >= fail_rate
    return _event(ts, source_id=source_id, event_type="login_attempt", src_ip=internal_ip(rng),
                  login_status="success" if ok else "failed", username=rng.choice(NORMAL_USERS))


def heartbeat_event(ts, source_id):
    return _event(ts, source_id=source_id, event_type="heartbeat")


# ---------------------------------------------------------------------------
# Attack patterns
# ---------------------------------------------------------------------------
def portscan_event(ts, attacker_ip, victim_ip="192.168.1.10", source_id="firewall-01", rng=random):
    return _event(ts, source_id=source_id, event_type="network_connection", src_ip=attacker_ip,
                  dst_ip=victim_ip, protocol="TCP",
                  port=rng.choice(SUSPICIOUS_PORTS + list(range(1, 1024))),
                  bytes_transferred=rng.randint(40, 120))


def exfil_event(ts, internal, attacker_ip, source_id="firewall-01", rng=random):
    return _event(ts, source_id=source_id, event_type="network_connection", src_ip=internal,
                  dst_ip=attacker_ip, protocol="TCP", port=rng.choice(SUSPICIOUS_PORTS),
                  bytes_transferred=rng.randint(500_000, 2_000_000))


def failed_login_event(ts, ip, username="admin", source_id="auth-server-01"):
    return _event(ts, source_id=source_id, event_type="login_attempt", src_ip=ip,
                  login_status="failed", username=username)


def success_login_event(ts, ip, username, source_id="auth-server-01"):
    return _event(ts, source_id=source_id, event_type="login_attempt", src_ip=ip,
                  login_status="success", username=username)


# ---------------------------------------------------------------------------
# Training baseline for the ML model
# ---------------------------------------------------------------------------
def _odd_event(ts, rng, source_id="firewall-01"):
    """A rare, unusual-but-not-necessarily-malicious event (misconfigured app,
    odd port, tiny probe, big transfer). Real unlabeled traffic always contains
    a small share of these; including them stops the model from treating
    everything outside the 'ordinary' range as identical."""
    return _event(ts, source_id=source_id, event_type="network_connection",
                  src_ip=rng.choice([internal_ip(rng), external_ip(rng)]),
                  dst_ip=rng.choice([internal_ip(rng), external_ip(rng)]),
                  protocol=rng.choice(["TCP", "UDP"]), port=rng.randint(1, 65535),
                  bytes_transferred=int(10 ** rng.uniform(1.3, 6.5)))


def baseline_events(n=4000, seed=7, odd_fraction=0.02):
    """Unlabeled training traffic: mostly normal plus ~2% unusual events."""
    rng = random.Random(seed)
    t = datetime(2026, 1, 1)
    out = []
    for _ in range(n):
        t += timedelta(seconds=rng.uniform(0.2, 1.2))
        out.append(_odd_event(t, rng) if rng.random() < odd_fraction
                   else normal_network_event(t, rng=rng))
    return out
