"""
detection/severity.py
----------------------
Decides Critical / Moderate / Low and whether a finding is HIGH-CONFIDENCE
(the only kind eligible for automated response). Rules are documented, not
arbitrary:

NETWORK_THREAT (ML score; lower = more unusual)
  score <  threshold - margin       -> Critical, high-confidence (strong signal)
  score <  threshold                -> Moderate (needs an analyst)
  ...but the same source flagged PERSISTENCE times -> Critical, high-confidence
  (one odd packet is a hint; sustained odd behaviour is a pattern)

AUTH_FAILURE (rule)
  failures >= threshold x multiplier -> Critical, high-confidence (clear brute force)
  failures >= threshold              -> Moderate (could be a user who forgot a password)

LOG_DELAY (rule)
  always Moderate, never auto-escalated, never triggers IP blocking: it flags
  a monitoring gap, not a proven attack.
"""

import config

RANK = {"Low": 0, "Moderate": 1, "Critical": 2}


def classify_network(score, occurrences=1):
    thr = config.ML_ANOMALY_SCORE_THRESHOLD
    if score < thr - config.ML_STRONG_SIGNAL_MARGIN:
        return config.SEVERITY_CRITICAL, True
    if score < thr:
        if occurrences >= config.ML_PERSISTENCE_COUNT:
            return config.SEVERITY_CRITICAL, True
        return config.SEVERITY_MODERATE, False
    return config.SEVERITY_LOW, False


def classify_auth(failed_count):
    thr = config.FAILED_LOGIN_THRESHOLD
    if failed_count >= thr * config.CRITICAL_ESCALATION_MULTIPLIER:
        return config.SEVERITY_CRITICAL, True
    if failed_count >= thr:
        return config.SEVERITY_MODERATE, False
    return config.SEVERITY_LOW, False


def classify_log_delay(_gap_seconds):
    return config.SEVERITY_MODERATE, False
