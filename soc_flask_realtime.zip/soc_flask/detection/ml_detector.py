"""
detection/ml_detector.py
-------------------------
Machine-learning part of the hybrid detection engine.

WHY Isolation Forest (viva point):
- UNSUPERVISED: it learns what "normal" looks like and flags what is
  different. No labelled attack data needed, which matches reality - a
  new SOC rarely has a clean labelled attack dataset.
- Works well on small numeric tables (port, bytes, protocol, burst rate).
- Light and explainable: no deep learning, as the project spec requires.

HOW it is used in the live system:
1. TRAIN once on a baseline of normal firewall events and save the model
   to model/isolation_forest.joblib (loaded on every later start).
2. SCORE every network event as it arrives (decision_function: the lower,
   the more unusual). Events below ML_ANOMALY_SCORE_THRESHOLD are
   suspicious; much lower = a strong signal (see detection/severity.py).

ML is applied ONLY to network events. Failed logins and silent log
sources are exact conditions, so plain rules are used (detection/rules.py).

Features per event (6): uncommon-port flag, log(bytes), protocol, how many
connections the source IP made in the last ML_BURST_WINDOW_SECONDS (burst),
how many DIFFERENT ports it touched in that window (the classic port-scan
signal), and whether the destination is internal or external.
"""

import os
from collections import defaultdict, deque
from datetime import datetime

import joblib
import numpy as np
from sklearn.ensemble import IsolationForest

import config
from traffic import baseline_events, COMMON_PORTS

MODEL_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                          "model", "isolation_forest.joblib")
PROTOCOL_MAP = {"TCP": 0, "UDP": 1}
COMMON = set(COMMON_PORTS)
FEATURE_NAMES = ["uncommon_port", "log_bytes", "protocol", "burst_count", "distinct_ports", "dst_internal"]


def _is_private(ip):
    return 1 if ip and (ip.startswith("192.168.") or ip.startswith("10.")) else 0


def feature_row(event, burst_count, distinct_ports):
    return [
        0 if event.get("port") in COMMON else 1,
        float(np.log1p(event.get("bytes_transferred") or 0)),   # log scale: sizes span orders of magnitude
        PROTOCOL_MAP.get(event.get("protocol"), -1),
        burst_count,
        distinct_ports,
        _is_private(event.get("dst_ip")),
    ]


def build_training_matrix(events):
    """Feature matrix for a time-ordered list of events (burst/distinct-port counts
    per source computed with a sliding window, same meaning as at live scoring time)."""
    window = config.ML_BURST_WINDOW_SECONDS
    recent = defaultdict(deque)
    rows = []
    for e in sorted(events, key=lambda x: x["timestamp"]):
        ts = datetime.fromisoformat(e["timestamp"]).timestamp()
        dq = recent[e["src_ip"]]
        dq.append((ts, e["port"]))
        while dq and dq[0][0] < ts - window:
            dq.popleft()
        rows.append(feature_row(e, len(dq), len({p for _, p in dq})))
    return np.array(rows, dtype=float)


def train_model(save=True):
    X = build_training_matrix(baseline_events())
    model = IsolationForest(n_estimators=200, contamination=config.ML_CONTAMINATION,
                            random_state=42)
    model.fit(X)
    if save:
        os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
        joblib.dump(model, MODEL_PATH)
    return model


def load_or_train():
    if os.path.exists(MODEL_PATH):
        try:
            return joblib.load(MODEL_PATH)
        except Exception:
            pass
    return train_model()


def score_event(model, event, burst_count, distinct_ports):
    """Anomaly score for one event. Lower = more unusual (negative = suspicious)."""
    row = np.array([feature_row(event, burst_count, distinct_ports)], dtype=float)
    return float(model.decision_function(row)[0])
