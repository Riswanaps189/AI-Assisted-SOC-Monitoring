"""
detection/rules.py
-------------------
The two clearly-defined SOC conditions, implemented as plain rules (no ML):

* Problem 2 - a log source silent for longer than LOG_DELAY_THRESHOLD_SECONDS
* Problem 3 - FAILED_LOGIN_THRESHOLD failed logins from one source inside
  FAILED_LOGIN_WINDOW_SECONDS

Why no ML here: both conditions are exact ("more than 3 minutes", "10 or more").
A threshold already describes them completely; ML would only add complexity.

False-positive note (Problem 3): a person who mistypes a password a few times
stays below the threshold and is not flagged. A success after many failures is
deliberately NOT treated as an all-clear - for a brute-force attacker, a success
means the guess worked.
"""

from datetime import datetime, timedelta

import config


def _iso(dt):
    return dt.isoformat(timespec="microseconds")


def failed_login_count(conn, ip, now):
    since = _iso(now - timedelta(seconds=config.FAILED_LOGIN_WINDOW_SECONDS))
    return conn.execute(
        "SELECT COUNT(*) FROM events WHERE src_ip = ? AND event_type = 'login_attempt' "
        "AND login_status = 'failed' AND timestamp >= ?", (ip, since)
    ).fetchone()[0]


def failed_logins_by_ip(conn, now, minutes=60):
    """Display helper: peak failures per source in the last `minutes`, with usernames."""
    since = _iso(now - timedelta(minutes=minutes))
    rows = conn.execute(
        "SELECT src_ip, COUNT(*) AS n, GROUP_CONCAT(DISTINCT username) AS users, MAX(timestamp) AS last_ts "
        "FROM events WHERE event_type = 'login_attempt' AND login_status = 'failed' "
        "AND timestamp >= ? GROUP BY src_ip ORDER BY n DESC", (since,)
    ).fetchall()
    return [dict(r) for r in rows]


def source_gap_seconds(conn, source_id, now):
    """Seconds since this source last sent ANY event (None if it never has)."""
    row = conn.execute("SELECT MAX(timestamp) AS t FROM events WHERE source_id = ?", (source_id,)).fetchone()
    if not row or not row["t"]:
        return None, None
    last = datetime.fromisoformat(row["t"])
    return (now - last).total_seconds(), last


def is_delayed(gap_seconds):
    return gap_seconds is not None and gap_seconds > config.LOG_DELAY_THRESHOLD_SECONDS
