"""
engine.py
---------
The real-time heart of the system. Everything that happens is event-driven:

  event arrives (POST /api/ingest, an agent, or the simulator)
      -> stored in the database
      -> checked at once:
           failed login      -> rule: N failures from one IP in the window?
           network event     -> ML:   does the Isolation Forest find it unusual?
      -> alert raised (or an existing incident updated / escalated)
      -> severity assigned -> automated response if Critical + high-confidence
      -> response recorded in the audit trail

A second background thread is the "clock": every few seconds it asks, for each
log source, "when did you last send something?" and raises a Log Delay alert
when the silence passes the threshold (Problem 2). It also lifts expired IP
blocks. This is why no "Run Scan" button is needed: detection is continuous.

Incident grouping: repeated detections for the same (alert type, source IP)
inside ALERT_COOLDOWN_SECONDS update ONE alert (occurrence counter, higher
severity if the evidence grows) rather than creating one alert per packet.
"""

import json
import re
import threading
import traceback
from datetime import datetime, timedelta

import config
from db.database import (
    get_connection, insert_event, insert_alert, insert_response, update_alert_status,
    is_ip_blocked, now_iso, clear_all,
)
from detection import rules
from detection.ml_detector import load_or_train, score_event
from detection.severity import RANK, classify_network, classify_auth, classify_log_delay
from response.ip_blocker import apply_response, expire_old_blocks

VALID_TYPES = {"network_connection", "login_attempt", "heartbeat"}
DEFAULT_SOURCE_TYPE = {"network_connection": "firewall", "login_attempt": "auth_server", "heartbeat": "agent"}


def fmt_duration(seconds):
    seconds = int(seconds)
    return f"{seconds // 60}m {seconds % 60:02d}s" if seconds >= 60 else f"{seconds}s"


def normalize_event(raw):
    """Validate an incoming event and fill defaults. Raises ValueError if unusable."""
    if not isinstance(raw, dict):
        raise ValueError("event must be a JSON object")
    etype = raw.get("event_type")
    if etype not in VALID_TYPES:
        raise ValueError(f"event_type must be one of {sorted(VALID_TYPES)}")
    source_id = str(raw.get("source_id") or "").strip()
    if not source_id:
        raise ValueError("source_id is required")

    ts = raw.get("timestamp")
    if ts:
        # Tolerate "Z" and >6 fractional digits (PowerShell emits 7) on every Python version.
        ts_clean = re.sub(r"(\.\d{6})\d+", r"\1", str(ts).strip().replace("Z", "+00:00"))
        try:
            dt = datetime.fromisoformat(ts_clean)
        except ValueError:
            raise ValueError("timestamp must be ISO-8601, e.g. 2026-10-05T14:30:00")
        if dt.tzinfo is not None:
            dt = dt.astimezone().replace(tzinfo=None)
    else:
        dt = datetime.now()

    def _int(name):
        v = raw.get(name)
        if v in (None, ""):
            return None
        try:
            return int(v)
        except (TypeError, ValueError):
            raise ValueError(f"{name} must be a number")

    status = raw.get("login_status")
    if etype == "login_attempt" and status not in ("success", "failed"):
        raise ValueError("login_status must be 'success' or 'failed' for login_attempt events")

    return {
        "source_id": source_id[:64], "event_type": etype, "timestamp": now_iso(dt),
        "src_ip": (str(raw["src_ip"])[:64] if raw.get("src_ip") else None),
        "dst_ip": (str(raw["dst_ip"])[:64] if raw.get("dst_ip") else None),
        "protocol": (str(raw["protocol"]).upper()[:8] if raw.get("protocol") else None),
        "port": _int("port"), "bytes_transferred": _int("bytes_transferred"),
        "login_status": status if etype == "login_attempt" else None,
        "username": (str(raw["username"])[:64] if raw.get("username") else None),
        "raw_json": None,
        "_source_type": raw.get("source_type") or DEFAULT_SOURCE_TYPE[etype],
    }


class Engine:
    def __init__(self):
        self.lock = threading.RLock()
        self.model = None
        self._stop = threading.Event()
        self._thread = None
        self.started_at = None
        self.events_ingested = 0

    # ------------------------------------------------------------------ life-cycle
    def start(self):
        if self._thread and self._thread.is_alive():
            return
        if self.model is None:
            self.model = load_or_train()
        self._stop.clear()
        self.started_at = datetime.now()
        self._thread = threading.Thread(target=self._monitor_loop, name="soc-monitor", daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()

    @property
    def monitor_running(self):
        return bool(self._thread and self._thread.is_alive())

    def _monitor_loop(self):
        while not self._stop.wait(config.LOG_DELAY_CHECK_INTERVAL_SECONDS):
            try:
                self.check_log_delays()
            except Exception:
                traceback.print_exc()

    def reset(self):
        with self.lock:
            clear_all()
            self.events_ingested = 0

    # ------------------------------------------------------------------ ingestion
    def ingest(self, raw):
        e = normalize_event(raw)
        source_type = e.pop("_source_type")
        with self.lock, get_connection() as conn:
            conn.execute(
                "INSERT OR IGNORE INTO sources (source_id, source_type, description, first_seen) VALUES (?,?,?,?)",
                (e["source_id"], source_type, e["source_id"], now_iso()),
            )
            event_id = insert_event(conn, e)
            self.events_ingested += 1
            ts = datetime.fromisoformat(e["timestamp"])
            if e["event_type"] == "login_attempt" and e["login_status"] == "failed" and e["src_ip"]:
                self._auth_check(conn, e, ts)
            elif e["event_type"] == "network_connection" and e["src_ip"] and config.ML_ENABLED and self.model is not None:
                self._network_check(conn, e, ts)
        return event_id

    # ------------------------------------------------------------------ detection
    def _auth_check(self, conn, e, ts):
        ip = e["src_ip"]
        n = rules.failed_login_count(conn, ip, ts)
        if n < config.FAILED_LOGIN_THRESHOLD:
            return
        severity, hc = classify_auth(n)
        self._raise(
            conn, alert_type="AUTH_FAILURE", src_ip=ip, source_id=e["source_id"], method="RULE", ts=ts,
            classify=lambda occ: (severity, hc), occurrences=n,
            description=(f"{n} failed login attempts from {ip} within "
                         f"{fmt_duration(config.FAILED_LOGIN_WINDOW_SECONDS)} (threshold {config.FAILED_LOGIN_THRESHOLD})"),
            detail={"src_ip": ip, "failed_count": n, "window_seconds": config.FAILED_LOGIN_WINDOW_SECONDS,
                    "threshold": config.FAILED_LOGIN_THRESHOLD, "username": e["username"]},
        )

    def _network_check(self, conn, e, ts):
        since = now_iso(ts - timedelta(seconds=config.ML_BURST_WINDOW_SECONDS))
        row = conn.execute(
            "SELECT COUNT(*) AS n, COUNT(DISTINCT port) AS d FROM events "
            "WHERE src_ip = ? AND event_type = 'network_connection' AND timestamp >= ?",
            (e["src_ip"], since)).fetchone()
        score = score_event(self.model, e, row["n"], row["d"])
        if score >= config.ML_ANOMALY_SCORE_THRESHOLD:
            return
        self._raise(
            conn, alert_type="NETWORK_THREAT", src_ip=e["src_ip"], source_id=e["source_id"], method="ML", ts=ts,
            classify=lambda occ: classify_network(score, occ), occurrences=None,
            description=(f"Suspicious network behaviour from {e['src_ip']} to {e['dst_ip']}:{e['port']} "
                         f"({e['bytes_transferred']} bytes; {row['n']} connections, {row['d']} different ports "
                         f"in {config.ML_BURST_WINDOW_SECONDS}s; anomaly score {score:.3f})"),
            detail={"event": {k: e[k] for k in ("src_ip", "dst_ip", "port", "protocol", "bytes_transferred")},
                    "anomaly_score": round(score, 4), "burst": row["n"], "distinct_ports": row["d"]},
        )

    def check_log_delays(self):
        """Problem 2: runs on the background clock, compares each source's last event to NOW."""
        now = datetime.now()
        with self.lock, get_connection() as conn:
            for s in conn.execute("SELECT source_id FROM sources").fetchall():
                sid = s["source_id"]
                gap, last = rules.source_gap_seconds(conn, sid, now)
                if gap is None:
                    continue
                open_alert = conn.execute(
                    "SELECT * FROM alerts WHERE alert_type = 'LOG_DELAY' AND source_id = ? "
                    "AND status IN ('OPEN','ACKNOWLEDGED') ORDER BY alert_id DESC LIMIT 1", (sid,)).fetchone()
                if rules.is_delayed(gap):
                    desc = (f"No logs from {sid} for {fmt_duration(gap)} (limit {fmt_duration(config.LOG_DELAY_THRESHOLD_SECONDS)}). "
                            f"This is a monitoring gap, not a confirmed attack.")
                    detail = json.dumps({"source_id": sid, "gap_seconds": round(gap), "last_seen": last.isoformat()})
                    if open_alert:
                        conn.execute("UPDATE alerts SET description = ?, detail_json = ?, updated_at = ? WHERE alert_id = ?",
                                     (desc, detail, now_iso(now), open_alert["alert_id"]))
                    else:
                        sev, hc = classify_log_delay(gap)
                        alert = {"alert_type": "LOG_DELAY", "severity": sev, "detection_method": "RULE",
                                 "src_ip": None, "source_id": sid, "description": desc, "detail_json": detail,
                                 "created_at": now_iso(now), "high_confidence": int(hc), "status": "OPEN"}
                        alert_id = insert_alert(conn, alert)
                        apply_response(conn, alert, alert_id)
                elif open_alert:
                    update_alert_status(conn, open_alert["alert_id"], "RESOLVED")
                    insert_response(conn, {"alert_id": open_alert["alert_id"], "ip": None, "action": "AUTO_RESOLVE",
                                           "actor": "SYSTEM", "timestamp": now_iso(now),
                                           "notes": f"Logs from {sid} resumed; log-delay alert closed."})
            expire_old_blocks(conn)

    # ------------------------------------------------------------------ alert upsert
    def _raise(self, conn, *, alert_type, src_ip, source_id, method, ts, classify, occurrences, description, detail):
        """Create a new incident or update/escalate the open one for the same (type, IP)."""
        cutoff = now_iso(ts - timedelta(seconds=config.ALERT_COOLDOWN_SECONDS))
        existing = conn.execute(
            "SELECT * FROM alerts WHERE alert_type = ? AND src_ip = ? AND updated_at >= ? "
            "AND status NOT IN ('FALSE_POSITIVE','RESOLVED') ORDER BY alert_id DESC LIMIT 1",
            (alert_type, src_ip, cutoff)).fetchone()
        ts_iso = now_iso(ts)

        if existing:
            occ = occurrences if occurrences is not None else existing["occurrences"] + 1
            severity, hc = classify(occ)
            if RANK[existing["severity"]] > RANK[severity]:          # never downgrade an incident
                severity, hc = existing["severity"], bool(existing["high_confidence"])
            hc = hc or bool(existing["high_confidence"])
            escalated = RANK[severity] > RANK[existing["severity"]] or (hc and not existing["high_confidence"])
            conn.execute(
                "UPDATE alerts SET severity = ?, high_confidence = ?, description = ?, detail_json = ?, "
                "occurrences = ?, updated_at = ? WHERE alert_id = ?",
                (severity, int(hc), description, json.dumps(detail), occ, ts_iso, existing["alert_id"]))
            if escalated:
                alert = dict(existing, severity=severity, high_confidence=int(hc))
                outcome = apply_response(conn, alert, existing["alert_id"])
                if outcome in ("BLOCKED", "ALREADY_BLOCKED") and existing["status"] == "OPEN":
                    update_alert_status(conn, existing["alert_id"], "RESPONDED")
            return existing["alert_id"]

        if is_ip_blocked(conn, src_ip):      # already restricted: its traffic would not reach us
            return None
        occ = occurrences if occurrences is not None else 1
        severity, hc = classify(occ)
        alert = {"alert_type": alert_type, "severity": severity, "detection_method": method,
                 "src_ip": src_ip, "source_id": source_id, "description": description,
                 "detail_json": json.dumps(detail), "created_at": ts_iso, "updated_at": ts_iso,
                 "occurrences": occ, "high_confidence": int(hc), "status": "OPEN"}
        alert_id = insert_alert(conn, alert)
        outcome = apply_response(conn, alert, alert_id)
        if outcome in ("BLOCKED", "ALREADY_BLOCKED"):
            update_alert_status(conn, alert_id, "RESPONDED")
        return alert_id


engine = Engine()
