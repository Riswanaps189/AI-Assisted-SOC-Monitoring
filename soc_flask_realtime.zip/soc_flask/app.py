"""
app.py - Flask entry point.

    python app.py      then open http://127.0.0.1:5000

On start-up the detection engine begins running in the background (it loads the
saved ML model, or trains one the first time - takes a few seconds). From then
on, every event sent to /api/ingest (by the simulator or a real agent) is
analysed the moment it arrives; nothing needs to be "run".
"""

from flask import Flask, render_template

from api import api
from db.database import init_db
from engine import engine


def create_app(start_engine=True):
    init_db()
    app = Flask(__name__)
    app.register_blueprint(api)

    @app.route("/")
    def index():
        return render_template("index.html")

    if start_engine:
        engine.start()
    return app


app = create_app()

if __name__ == "__main__":
    print("SOC engine running. Dashboard: http://127.0.0.1:5000")
    app.run(host="127.0.0.1", port=5000, debug=False, threaded=True)
