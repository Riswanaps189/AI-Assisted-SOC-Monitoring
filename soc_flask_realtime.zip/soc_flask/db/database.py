"""
db/database.py
---------------
All persistence lives in one SQLite file (zero setup, real relational schema).

Tables
------
sources       : every log source that has ever sent an event (auto-registered)
events        : raw ingested events (network, login attempts, heartbeats)
alerts        : incidents; repeated detections for one (type, IP) are folded
                into one row with an `occurrences` counter
blocked_ips   : automated / manual IP restrictions with expiry
response_log  : audit trail of every automated or manual action

WAL mode + a busy timeout let the API threads, the live engine and the
simulator all write safely at the same time.
"""

import os
import sqlite3
from contextlib import contextmanager

import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS sources (
    source_id     TEXT PRIMARY KEY,
    source_type   TEXT NOT NULL,
    description   TEXT,
    first_seen    TEXT
);

CREATE TABLE IF NOT EXISTS events (
    event_id          INTEGER PRIMARY KEY AUTOINCREMENT,
    source_id         TEXT,
    event_type        TEXT NOT NULL,   -- network_connection / login_attempt / heartbeat
    timestamp         TEXT NOT NULL,
    src_ip            TEXT,
    dst_ip            TEXT,
    protocol          TEXT,
    port              INTEGER,
    bytes_transferred INTEGER,
    login_status      TEXT,            -- success / failed / NULL
    username          TEXT,
    raw_json          TEXT
);
CREATE INDEX IF NOT EXISTS idx_events_src_time  ON events (src_ip, timestamp);
CREATE INDEX IF NOT EXISTS idx_events_source_time ON events (source_id, timestamp);
CREATE INDEX IF NOT EXISTS idx_events_type_time ON events (event_type, timestamp);

CREATE TABLE IF NOT EXISTS alerts (
    alert_id         INTEGER PRIMARY KEY AUTOINCREMENT,
    alert_type       TEXT NOT NULL,    -- NETWORK_THREAT / LOG_DELAY / AUTH_FAILURE
    severity         TEXT NOT NULL,    -- Critical / Moderate / Low
    detection_method TEXT NOT NULL,    -- ML / RULE
    src_ip           TEXT,
    source_id        TEXT,
    description      TEXT,
    detail_json      TEXT,
    created_at       TEXT NOT NULL,
    updated_at       TEXT NOT NULL,
    occurrences      INTEGER DEFAULT 1,
    high_confidence  INTEGER DEFAULT 0,
    status           TEXT DEFAULT 'OPEN'  -- OPEN / RESPONDED / ACKNOWLEDGED / FALSE_POSITIVE / RESOLVED
);
CREATE INDEX IF NOT EXISTS idx_alerts_type_ip ON alerts (alert_type, src_ip, updated_at);

CREATE TABLE IF NOT EXISTS blocked_ips (
    block_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    ip           TEXT NOT NULL,
    alert_id     INTEGER,
    blocked_at   TEXT NOT NULL,
    expires_at   TEXT NOT NULL,
    active       INTEGER DEFAULT 1,
    triggered_by TEXT                  -- AUTO / MANUAL
);

CREATE TABLE IF NOT EXISTS response_log (
    response_id INTEGER PRIMARY KEY AUTOINCREMENT,
    alert_id    INTEGER,
    ip          TEXT,
    action      TEXT NOT NULL,         -- BLOCK_IP / UNBLOCK_IP / NOTIFY_ONLY / ACKNOWLEDGE / ...
    actor       TEXT NOT NULL,         -- SYSTEM / ANALYST
    timestamp   TEXT NOT NULL,
    notes       TEXT
);
"""


def get_db_path():
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base_dir, config.DB_PATH)


@contextmanager
def get_connection():
    conn = sqlite3.connect(get_db_path(), timeout=15)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with get_connection() as conn:
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.executescript(SCHEMA)


def clear_all():
    """Delete every row (keeps the schema). Used by the Reset button."""
    with get_connection() as conn:
        for table in ("response_log", "blocked_ips", "alerts", "events", "sources"):
            conn.execute(f"DELETE FROM {table}")
        conn.execute("DELETE FROM sqlite_sequence")


def now_iso(dt=None):
    from datetime import datetime
    return (dt or datetime.now()).isoformat(timespec="microseconds")


def insert_event(conn, e: dict):
    keys = ("source_id", "event_type", "timestamp", "src_ip", "dst_ip", "protocol",
            "port", "bytes_transferred", "login_status", "username", "raw_json")
    row = {k: e.get(k) for k in keys}
    cur = conn.execute(
        """INSERT INTO events (source_id, event_type, timestamp, src_ip, dst_ip, protocol,
                               port, bytes_transferred, login_status, username, raw_json)
           VALUES (:source_id, :event_type, :timestamp, :src_ip, :dst_ip, :protocol,
                   :port, :bytes_transferred, :login_status, :username, :raw_json)""",
        row,
    )
    return cur.lastrowid


def insert_alert(conn, a: dict):
    row = {
        "alert_type": a["alert_type"], "severity": a["severity"],
        "detection_method": a["detection_method"], "src_ip": a.get("src_ip"),
        "source_id": a.get("source_id"), "description": a.get("description"),
        "detail_json": a.get("detail_json"), "created_at": a["created_at"],
        "updated_at": a.get("updated_at", a["created_at"]),
        "occurrences": a.get("occurrences", 1),
        "high_confidence": a.get("high_confidence", 0), "status": a.get("status", "OPEN"),
    }
    cur = conn.execute(
        """INSERT INTO alerts (alert_type, severity, detection_method, src_ip, source_id,
                               description, detail_json, created_at, updated_at, occurrences,
                               high_confidence, status)
           VALUES (:alert_type, :severity, :detection_method, :src_ip, :source_id,
                   :description, :detail_json, :created_at, :updated_at, :occurrences,
                   :high_confidence, :status)""",
        row,
    )
    return cur.lastrowid


def insert_block(conn, b: dict):
    cur = conn.execute(
        """INSERT INTO blocked_ips (ip, alert_id, blocked_at, expires_at, active, triggered_by)
           VALUES (:ip, :alert_id, :blocked_at, :expires_at, :active, :triggered_by)""",
        b,
    )
    return cur.lastrowid


def insert_response(conn, r: dict):
    row = {"alert_id": r.get("alert_id"), "ip": r.get("ip"), "action": r["action"],
           "actor": r["actor"], "timestamp": r["timestamp"], "notes": r.get("notes")}
    cur = conn.execute(
        """INSERT INTO response_log (alert_id, ip, action, actor, timestamp, notes)
           VALUES (:alert_id, :ip, :action, :actor, :timestamp, :notes)""",
        row,
    )
    return cur.lastrowid


def update_alert_status(conn, alert_id: int, status: str):
    conn.execute("UPDATE alerts SET status = ? WHERE alert_id = ?", (status, alert_id))


def is_ip_blocked(conn, ip: str) -> bool:
    row = conn.execute(
        "SELECT 1 FROM blocked_ips WHERE ip = ? AND active = 1 LIMIT 1", (ip,)
    ).fetchone()
    return row is not None
